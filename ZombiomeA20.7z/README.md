Zombiome is a mod for 7DaysToDie

With a big thank to the forums' community - to all of you that help, answer questions and provide great tutorials ...

Umbrella proudly presents

# Zombiome

 Behold survivors !
Mother Hearth has been soiled long enough by these nasty Zombies. It can stand no more and its revolt has started. Biomes won't make a distinction between the livings and the undeads.

### Current status

Experimental
The mod is globally stable and playable. A few errors may still occur but crashes are rare.

Version : 2.0 (Dust,Craft,AdvancedActivities)
Tested Vanilla: 20.6 (b9)
Single Player only

## Biome Activity

The world has permanent random activities. Most are apocalyptic natural disasters. A few of them are more "supernatural". Activities are structured by location and biomes. Alternate light episodes and crisis. Intensity and frequency depend on position. 

Around 40 Biome Activities, including:
- Volcanic eruption, Lava flows
- Meteore strikes, starfall
- Earthquakes, sismic ground motions, flood, geyser
- Gaz emanations (fire, poison, freeze, enlighten, blind ... )
- Bushfires, wissfires, electric disturbances, radiations
- Twisters, Moving / flying / floating biome decorations, slime blocks 
- Altered physics (gravity, sizes and motion, repulsive fields, non-igniting gun powder ...)
- Player inventory alterations (evaporate, rotten, stuck bag, filling)
- Zombies: a few enhanced attacks, AIs and specials.
- 13 "minibiomes", combining re-textured decorations, moving colliding particles and area buffs.

### Gameplay hints

Biome activities can be tough. If you don't like what is happening around you, move and explore new areas. Observe your surroundings, some may be used to your advantage. Don't forget to learn affinity powers and craft.

## Biome Affinity

Learn to control biomes by completing special challenges at epicenters.
- BiomeDust unlocks 40 powers: attacks, aoes, pets, stat bonuses, block/biome/entity-motion alterations, construction... 
- Hard-to-master. Draw energy from specific materials.

### Craft system
*80+ craftable items* to complement the BiomeDust:
- Under new Biome Awareness attribute (no skill point needed).
- 35+ powerful attachements for melee, guns and turrets. Some weapons (Frost harpoon, pegasus glove).
- Modified attacks, 3rd weapon attack (charge, dodge, shield ...), vehicle actions.
- Blocks, traps (stalagmice, slime, rooting roots, fertilizer block, elemental fields, regenerating walls ...)
- Consumables, Equipment (bouncy shoes and armor, glasses with various detection ability ...)


# Mod Usage

ZomBiome is distributed under a BSD 2 License 

## Instal

Coming soon ...

## Warnings

Important Warnings to players
- Could mess up your saves. Duplicate your savefile or start a new game !
- Could break at any release
- Balance or performance sometimes so-so.
- In sismic areas, any container (and its content !) could be destroyed in a second.
Landclaim/bedroll have small sismic-free zone. Think twice before chosing location of your base and chests.
- Not yet tested by many players.

## Customize

While Zombiome runs, you should periodically see a long line printed in the console (F1), starting with "ZombiomeManager update ... ".
Zombiome should *start automatically* when player spawns. If it does not, or stops for any reason, use command "zb start".

The REAMDE.md contains detailed instructions (commands, xml ...):
- Through XML, change the global activity strength (rate, duration, concentration) and set each activity weight separately.
- Zombiome commands and items can help you alter landscapes for your own edited maps.
- God-mod command for infinite affinity and color selection : "zb D" (easier Dust and item testing)

Any feedback appreciated !


## Creative mode and tests

You can use Zombiome commands and items to alter landscape and biomes manually.

*Run a specific activity* around you.
- eg command "zb start Peak", and "zb pause" once you are done.
- Activity "Peak" can be any activity key used by buff ZombiomeManager in buffs.xml (eg Meteorite, Twister, Volcano ...) or any entry from the list minibiomes="Ejector,Moisture,Evaporate,Rotten...".
- Command "zb nz 1" or "zb nz 4" to select 1 or 4 activities running at once.
- Toggle "zb f" so that activity permanently runs.
- Some direct commands too: "zbtest Volcano", "zbtest Twister"

Use BiomeDust powers and craftable (eg Terraforms).
If you want to use or test Zombiome items, you need *fullfill its affinity condition*.
- Command "zb D" : sets awareness=20, permanent affinity generation, and ability to select your color and burst using radial menu of the BiomeDust (key R). Also tracks closest epicenter on minimap.
- Toggle "zb D" to revert to normal.

Try epicenters challenges
- "zb tp i j" teleports to epicenter indices i,j (|i,j| > 8 could be in radioactive zone depending on map size). 

## XML tuning

Zombiome allows you to set the global activity strength (rate, duration, concentration); to turn on/off each Zombiome activity; and to turn affinity system off.

**Gameplay**
- If you hate magic powers, turn <zombiome_empowered="false"> (the epicenter challenge then only gives you a sellable reward, no more dust).
- If you dislike supernatural activities, turn off activities (set weight values to "0") for: AttractivePlayer, Gravity, Jumping, DwarfPlayer, RandomSize, Giant, MovingDeco, MadTrees, FloatingDeco, WaveFlood, Minibiomes.
- If you want a much quieter Zombiome, set eg <intensity="0.1,0.3">, <epi_amortize="2"> and <epi_perm_intensity="0.1"> 

**Performance**
If the game is too often laggy, set eg <intensity="0.1,0.3">, <nz=1>, <manager_frequency="10">. 

**Details**
Under the <buff name="ZombiomeManager"> at bottom of buffs.xml, you'll find values you can edit:
- <intensity="0.1,0.7"> : epicenters are active between 10% and 70% of the time.
- <frequency="1,30">: epicenters have between 1 and 30 crisis / (rl-) hour
Each epicenter draws 1 value uniformly in the 2 intervals above.
- <zombiome_empowered="true"> : Activate biome powers (affinity and biomedust)
- <dust_low="2" dust_high="9"> : How much inactive dust remains from a BiomeDust
- Activities Weight, eg <"TrapLine="3" LavaFlow="1"	MovingDeco="3"	MadTrees="2">. Let you decide the weight of each activity for epicenters map generation. Set to 0 to disactivate activities you dislike.

## Troubleshoot, tests

While Zombiome runs, you should periodically see a long line printed in the console (F1), starting with "ZombiomeManager update ... ".
Zombiome should *start automatically* when player spawns. If it does not for any reason, use command "zb start".

If you have *frequent errors* that prevents you from playing, try:
1) Command "zb pause", wait 1mn for current activities to stop
2) Once the game is stabilized, move away and resume activity: command "zb start" (if you resume without moving, the bug could come again). Stay away (>600m) from the buggy area.
3) Worse case : command "zb stop", and once stabilized, save your game and restart the client.

Please, if you see any error, share Zombiome dedicated log error file: /Mods/zb_err.txt. I'll try to adress any unplayability problems fast.

## Commands

### Zombiome activity
zb pause : pause ZB activity (already running effects still need to finish)
zb start : restart ZB activity (or start if automatic start failed)
zb start X : select the activity to run, eg "zb start Volcano". All possible X are described in the xml. 
zb nz 1 / zb nz 4 : Activity uses 1 or 4 (default=4) adjacent areas. 1 useful for testings
zb f : toggle "always active" activity (default=false)

zb tp i j: teleport to the epicenter at chunk i,j (eg zb tp 0 0 should send you at center of the map)
zb epit: track the closest epicenter (marker on compass, toggle)
zbtest Volcano: creates a volcano where you are looking at

zb stop: definite stop of all activities (need to relaunch game to start Zombiome again)

zb D: combines zb m (gives mana), zb md (you can chose dust color by holding reload) and zb epit. Also gives Awareness attribute.

### Various
zbtest fwd x : teleport x meters forwards (lookray)
godi: equip a few weapon + CM + DM
godi w: gives a variery of weapons
godi wm: give melee weapons equipped w Zombiome item_modifiers
godi wg: give gun/armor equipped w Zombiome item_modifiers
godi start: completes basic survival and give white citizen
sbuff buff entitId (default=self) : "sbuff -buff" removes it
sbuff $cvar (value) : get or set a cvar on you


## Zombiome Epicenter Generation
Map divided in 288x288 Zones (xml: zone_size).
An epicenter is drawn unformly in each.

Zone seed and biome determines Activity and it parameters
Zone seed determines average pace and duration

At any position the 4 adjacent epicenters are active (xml or command: nz=1 or nz=4)
With intensity depending on distance (xml: epi_amortize).

### Zombiome Epicenter Challenge
At each epicenter lays a weird biome decoration. Interact with it to harvest BiomeDust and start the challenge.

During 30 sec, the 4 active Zones have forced activity. The main Zone focuses toward player. Moreover randomly : Extra peak/collapse effects, extra vanilla horde, extra special zombies.

The challenges are harder and harder (for instance, try a challenge after running command "sbuff $zb_activations 50"). You get extra inactive dust if you stay in challenge zone.

## Zombiome Activity List

Note in parenthesis : (1)=very realistic, (4)=looks like magic

### Ground Motion / Alteration
The earth moves up or down in different shape. Zone hash and biome determines inserted block, reproductibility, and physics (elasticity, reversal, and avoidance of block/entity/small_decorations). Usually located at earth surface.
- Peak, Rift, Wave (1)
- Flood, RiftCollapse, Cave (1)

Others:
- WaveFlood (3): cubic wave of waters appear and vanish
- Geyser (1): vertical water peaks
- Slime (2): spawn bouning slime blocks on the ground
- Volcano (1): erupts periodically at repro location. Shape mountain, lava flow, erupt fire and thrown boulders.
- SwallowGround (2): ground opens below entities, swallow them, then spits out.

### Decoration Alteration 

- TrapLine (2): Lines of traps on the ground. Block depends on biome (traps)
- LavaFlow (1): Lava emanates from the ground and flows. Biome -> % of bioplasm flow
- MovingDeco (4): Decorations blocks move around
- MadTrees (2): Trees grow fast and die
- WildGrass (1): Dense grass grow, limits visibility.

### Air Alteration 

Gaz, Emanation, bushfire
- Fire (at disjoint location) and FireStorm (in moving line) (1) 
Throw invisible projectiles on ground, that create gaz or fire on collide. Projectiles depends on biome and zonehash (freeze, blind, poison, fire, eject).

Others:
- Twister (1): spawn periodically at repro location 
- Wind (2): Decorations transform to thrown projectiles and back to block.
- Meteorite (2): Meteores fall from the sky. Zonehash -> projectile and locations.
- BlockRain (4): blocks rain from the sky
- FloatingDeco (4): blocks levitate in the air then back down. Inserts a temporary stability air block.

### Entity Alteration 

ElectroMagnetic/Fire Disturbances
- Ghost (3): The disturbance depends on biome and zone hash (fire, yellow fire, firepillar, fire/eject balls) and type (bolt, ghost and bombs).

- Souls (4) Souls emerge from dead Zombies and try to possess the player.
- Giant (4): A nearby Zombie is turned into a Giant
- RaiseDead (1): Zombies/animals raise up from the ground
- Gravity (3): Altered gravity through entity buff. Zone hash -> Gravity, GStrong or Antigravity
- Jumping (2): entities are regularly ejected from ground
- RandomSize (2):  Zombies alternate between normal, small&fast and large&slow

### Inventory Alteration 
- FillBag (1): inserts dummy resources into player bag.
- StuckZip (1): backpack zip is stuck. Menus cannot be opened. Buff based

### Minibiomes
- Minibiomes (4)

All controled through the same "Minibiomes" activity. The concrete type depends
on biome and hash. Minibiomes combine:
- Retextured decoration blocks (possibly applying buffs), more dense near epicenter
- Ghost (invisible passive entity) with various graphical/contact effects and motion
- Global buff

Minibiome list:
- Ejector: Entities become ejectable. Blue sky pattern. BlueGlow texture.
- Moisture: guns can't fire. Water texture.
- Evaporate: water in bag evaporate. Water Stat degrade. Gold textures. yfire ghost.
- Rotten: water or food in bag is slowly destroyed. Flesh textures, blood ghost.
- Rock: melee is very slow. Rock textures, sparkle ghost.
- Snow: Mad temperature. Snow textures.
- Glow: Attractive and injecting buff. Lighting ghost. Red textures.
- Rooting: entities are randomly rooted to the ground. Wood textures.
- Slippery: item in hand can drop to the ground. Oil textures.
- Fiery: Zombie "Fire" special attack. Fire textures, large yfire ghost.
- Dusty: Zombie "Ground Peak" special attack: dense smoke ghost.
- Radiated: Blocks and Zombie slighlty irradiate the player. Green textures.
- Vanishing: Zombie alternate visible/invisible.

## ZombiomeDust Powers

Attack 1 triggers with melee attack (left mouse btn), 2 with throw (right mouse), 3 with activate (Key F) and 4 with reload (key R).

Some actions trigger at position you are looking at (modulo some max range)

### Green (plant)
1 Hit, @heal : Melee attack. Hitting a green@ block restores 1hp with 3sec cooldown.
2 Clay Peak : a clay peak emerges from the ground. Physics depends on Zone.
3 SkyLadder : A temporary growing ladder
4 Cactus : Spawn a cactus
### Green Burst (tree)
1 Woodskin : Greatly increase attack speed, but depletes stamina. Attacks root the target.
2 Summon Wolf : friendly
3 WoodWall : traps emerge from the ground
4 Cure : remove all negative statuses
### Red (stone)
1 StoneRain : small rocks fall from the sky
2 Rock : throw a large rock.
3 StoneWall
4 RockSkin : reduces damage and mobility
### Red Burst (fire)
1 Summon Living Flame
2 Hell Fire : a long and tough fire
3 Wild fire : a large range ground fire
4 Meteore Rain
### Black (shadow)
1 Hit, @mana : melee attack. Hitting zombie gives you @
2 SwallowCavern
3 Vanish : you become invisible. Broken on first attack, having +100% dismember
4 BloodyCoffee : spawns a magical coffee plant that give coffee buff when walked on.
### Black Burst (death)
1 Leecher. Improves damage, melee attacks on zombie or black@ blocks heal you.
2 Summon Devil Bear - not friendly, limited duration.
3 Earthquake
4 DreadSkin - the next zombie hitting you dies.
### Blue (water)
1 Melee, apply slows. Only damages wet target
2 WaterBall. Apply wet and slow.
3 Slimes
4 WaterWall : temporary large water wall
### Blue Burst (cold)
1 HailStorm -
2 IceBall -
3 IceWall - spawn stalagmice on the ground
4 IceSkin - you are immune but cannot move.
### White (metal)
1 Melee attack. Apply charges. Increase attack speed after attacking white@ block.
2 GlassWall : a temporary wall, first strong then fragile.
3 Magnetic Field : the ground rises up and floats
4 MetalSkin : blinds nearby entitites
### White Burst (lightning)
1 Charged Jump : a Jumping attack
2 Energy : shockss and eject
3 ElectricField : spawnl living sparkles.
4 Fly Jump : a very high jump


# Code Guide

### Harmony patches

StartOnPlayerExit, StartOnPlayerSpawn: hooks that start Zombiome activity processes. "zb start" to start manually.

FilterTagRecipes: Allows filter the recipe list by keyword "zombiome"

RandomTreeFall: trees fall in random directions when cut down. Hacky (change player position around the tree then back without yielding to the game).

BlockBackpack: prevents windows from opening while player is under buff "nosack".

PreventFire: prevents guns fire while under buff "nogun".

DynamicMeleeRadialExtra, DynamicMeleeRadialIs : Add Reload action on ALL ActionDynamicMelee. By default, the radial list is empty, so the button does nothing and the circular menu does not even show up. Used by stances item_mods. 

EntityAttackTimeout: Allows cvar $ZB__AtkTimeout to multiply the delay between 2 attacks.

SpeedMultiplierZombie, SpeedMultiplierEntityA : allows cvar EntitySpeedMultiplier_ZB to multiply the aggro speed of Zombie or EntityAlive.

TurretBuffs, TurretSledgeBuffs: allows turrets item_modifiers to trigger on hit and attacks of the deployed turret.


*under construction*

1) Activity start
- buffZombiomeManager starts local coroutines

2) Zone, areas, effect generation
- 
3) Effects implementation

## Known issues, todo list
Retexture
- Render retexture blocks from distance
- While placing reshape/retextured block, the raw one appears 
- Render retexture blocks hit performance (not memoized)
BlockMotion
- Ground motion: Multiblock poorly managed (horizontal and vertical support)
- TileEntity re-created (container content is dropped) 
- Moved block don't restore shape
- SwallowGround may leave holes
- Floating water decorations
- Sismic motion below lakes are laggy (vanilla game issue). "zbtest WaterBalance"
Misc
- Multiplayer is broken
- @ffinity / degradation bar only refreshed when holding BiomeDust. UI buff ?
- "broken glass" sound for fire activities
- Vanilla log files redirected
- Release GC pressure (in-place ops Vector3 & str)
- More accurate Entity motion (retroaction?)
Warnings
- Few NPEs on game exit while Twister
- Warning "Particle system is trying to spawn on a mesh w 0 surface area" (Fire meteore)
- Warning "Shoulb be parent but is not" (all block motion, MadTree)
- Warning "out of bound vertices"


