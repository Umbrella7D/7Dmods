﻿using System;
using System.Xml;
using UnityEngine;

// Token: 0x0200052F RID: 1327
public class MinEventActionMyAttachParticleEffectToEntity : MinEventActionAttachParticleEffectToEntity {
    /** Proxy when testing an actual variation without changing xml again */

}
