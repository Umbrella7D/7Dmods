using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;

using itools;

public class EffectsEntity {
    /*
    FIXME: 


    ---
    
    GameManager. public void SpawnBlockParticleEffect(Vector3i _blockPos, ParticleEffect _pe)
    
    Block.SpawnDestroyParticleEffect
    => _world.GetGameManager().SpawnParticleEffectServer(new ParticleEffect("blockdestroy_" + destroyParticle, World.blockToTransformPos(_blockPos) + new Vector3(0f, 0.5f, 0f), _lightValue, _color, this.blockMaterial.SurfaceCategory + "destroy", null, true), _entityIdThatCaused);
	

    			Vector3 pos = this.WireNode.GetEndPosition() + this.WireNode.GetEndPositionOffset();
			float lightValue = GameManager.Instance.World.GetLightBrightness(World.worldToBlockPos(this.BlockPosition.ToVector3())) / 2f;
			ParticleEffect pe = new ParticleEffect("electric_fence_sparks", pos, lightValue, new Color(1f, 1f, 1f, 0.3f), "electric_fence_impact", null, false);
			GameManager.Instance.SpawnParticleEffectServer(pe, -1);
			this.particleDelay = 0.5f;
    
    ----
    Entity subclasses :

    EntityAlive
        EntityAnimal, EntityCar, EntityEnemy (Animal, Flying, Zombie, Dog), EntityNPC (Bandit, Survivor), EntityPlayer, EntitySupplyCrate, EntityTurret, EntityVehicle (Driveable)
    EntityFallingBlock
    EntityFallingTree
    EntityItem
        EntityBackpack, EntityLootContainer
    EntitySupplyPlane

    */
       /*  public static void Spawn_v2(int entityID, Emplacement place, string entityGroup) { // fixme entityID useless here
        int spawnKey = this.entityIDs[UnityEngine.Random.Range(0, this.entityIDs.Count)];

        if (SingletonMonoBehaviour<ConnectionManager>.Instance.IsServer) 
            QuestActionSpawnEntitySDX.SpawnQuestEntity(spawnKey, OwnerQuest.SharedOwnerID, null);
        else
            SingletonMonoBehaviour<ConnectionManager>.Instance.SendToServer(NetPackageManager.GetPackage<NetPackageQuestEntitySpawn>()
                    .Setup(spawnKey, -1), false);
        }
     } */
    /* ******************** Spawn ******************** */

    private static bool UseTP(Entity entity) {
        /*FIXME: les vehicules ne retombent pas ..
        */
        if (entity as EntityPlayer != null) return true;
        if (entity as EntityVehicle != null) return true;
        if (entity as EntityItem != null) return true;
        return false;
    }
    public class MotionType {}

    private readonly static float FPS = 1f;
    public static IEnumerator Merge(List<IEnumerator> enumerators, double duration= 1f, int interleave=0) {
        DateTime t0 = DateTime.UtcNow;
        while(DateTime.UtcNow - t0 < TimeSpan.FromSeconds(duration)) {
            foreach(IEnumerator enumerator in enumerators) enumerator.MoveNext();
            yield return new WaitForEndOfFrame();
            for (int k=0; k<interleave; k++) yield return new WaitForEndOfFrame();
        }
        yield return null;
    }

    public static IEnumerator _MoveVelocity(Entity entity, Vector3 toward, float speed, float duration, int interleave) {
        /// duration is in second
        /// speed is block per frame       
        speed = speed / 2f; /// Correctif
        toward = toward * speed / FPS / (1+interleave); // toward = toward.normalized * speed;
        DateTime t0 = DateTime.UtcNow;
        while(DateTime.UtcNow - t0 < TimeSpan.FromSeconds(duration)) {
            GameManager.Instance.AddVelocityToEntityServer​(entity.entityId, toward) ;
            yield return new WaitForEndOfFrame();
            for (int k=0; k<interleave; k++) yield return new WaitForEndOfFrame();
        }
        yield return null;
    }
    public static IEnumerator _MoveVelocity(Entity entity, Vector3 toward, float speed, int duration, int interleave) {  
        speed = speed / 2f; /// Correctif    
        toward = toward * speed/ (1+interleave); // toward = toward.normalized * speed;
        for (int f=0; f<duration; f++) {
            GameManager.Instance.AddVelocityToEntityServer​(entity.entityId, toward);
            yield return new WaitForEndOfFrame();
            for (int k=0; k<interleave; k++) yield return new WaitForEndOfFrame();
        }
        yield return null;
    }
    public static IEnumerator _MoveSetPos(Entity entity, Vector3 toward, float speed, float duration, int interleave) {
        /// duration is in second
        /// speed is block per frame
        DateTime t0 = DateTime.UtcNow;
        toward = toward * speed / FPS / (1+interleave);
        while(DateTime.UtcNow - t0 < TimeSpan.FromSeconds(duration)) {
            entity.SetPosition(entity.GetPosition() + toward, false); // TODO test true
            yield return new WaitForEndOfFrame();
            for (int k=0; k<interleave; k++) yield return new WaitForEndOfFrame();
        }
        yield return null;
    }
    public static IEnumerator _MoveSetPos(Entity entity, Vector3 toward, float speed, int duration, int interleave) {
        toward = toward * speed / (1+interleave);
        for (int f=0; f<duration; f++) {
            entity.SetPosition(entity.GetPosition() + toward, false); // TODO test true
            yield return new WaitForEndOfFrame();
            for (int k=0; k<interleave; k++) yield return new WaitForEndOfFrame();
        }
        yield return null;
    }

    public static IEnumerator Move(Entity entity, Vector3 toward, float speed=1f, float duration=1f, int interleave=0) {
        if (UseTP(entity)) return _MoveSetPos(entity, toward, speed, duration, interleave);
        else return _MoveVelocity(entity, toward, speed, duration, interleave);
    }
    public static IEnumerator Move(Entity entity, Vector3 toward, float speed=1f, int duration=1, int interleave=0) {
        if (UseTP(entity)) return _MoveSetPos(entity, toward, speed, duration, interleave);
        else return _MoveVelocity(entity, toward, speed, duration, interleave);
    }
    public static void Teleport(Entity entity, Vector3 at, bool relative=false) {
        /// FIXME: pour Z, ca saute bcp plus !
        bool tp = UseTP(entity);
        Vector3 current = entity.GetPosition();
        Vector3 dest = relative ? (current + at) : at;
        if (tp) entity.SetPosition(dest, false); // TODO test false
        else {
            float speed = 1f / 2f; /// Correctif    
            Vector3 delta = dest - current;
            Debug.Log(String.Format("TeleportVelo: {0} {1} delta={2} at={3}", entity.entityId, entity.name, delta, at));
            GameManager.Instance.AddVelocityToEntityServer​(entity.entityId, delta * speed); // for 1 frame
        }
    }


    public static Entity Spawn(int entityID, Emplacement place, string entityName) { // fixme entityID useless here        

         Debug.Log(String.Format("Spawn ??"));

        // TODO: use        
/*         foreach (KeyValuePair<int, EntityClass> keyValuePair in EntityClass.list.Dict) {
            //if(keyValuePair.Value.entityClassName.StartsWith("Zombie")) {
            Debug.Log(String.Format("EntityClass.list.Dict: {0} {1}", entityID, keyValuePair.Value.entityClassName));
            if(keyValuePair.Value.entityClassName == "zombieBoe") {
                entityID = keyValuePair.Key;
                Debug.Log(String.Format("Spawn, id= {0} {1}", entityID, keyValuePair.Value.entityClassName));
                // zombieXXX
                // fallingTree / Block
                // animalXXX vehiculeXXX
                // BackPack
                // item
                // npc

            }
        } // sinon utiliser quete !
        Debug.Log( "zombieBoe?" + entityID.ToString()); */

        if (entityName == "") entityName = "zombieBoe";
        entityID = EntityClass.FromString(entityName); // "zombieBoe" animalSnake
        Debug.Log( "zombieBoe?" + entityID.ToString());
            
            // keyValuePair.Key, keyValuePair.Value, keyValuePair.Value.entityClassName

        long _chunkval = 0L;
        // string entityGroup = "ZombiesWasteland"; // zombieFarmer
        int ClassID = 0;
        /* Entity ID */
        /* // int zid = EntityClass.GetEntity("zombieFarmer").entityID; // 'EntityClass' does not contain a definition for 'GetEntity'
        // int zid = EntityClass.GetEntityByName("zombieFarmer").entityID;
        entityID = EntityGroups.GetRandomFromGroup(entityGroup, ref ClassID);   
        if (entityGroup != "") entityID = EntityGroups.GetRandomFromGroup(entityGroup, ref ClassID);  
        // else entityID = this.entityIDs[UnityEngine.Random.Range(0, this.entityIDs.Count)]; */
        Debug.Log(String.Format("Spawn: {0} {1}", entityID, Vectors.ToFloat(place.position)));

        // 
        /* Create */

        

        Entity entity = EntityFactory.CreateEntity(entityID, Vectors.ToFloat(place.position)); 
        Debug.Log(String.Format("Spawn: {0}", entity));
        // Entity NewEntity = EntityFactory.CreateEntity(EntityID, transformPos, entity.rotation) as Entity;
        // entity.SetSpawnerSource(EnumSpawnerSource.StaticSpawner, _chunkval, entityGroup);
        
        entity.SetSpawnerSource(EnumSpawnerSource.Dynamic); // entity 0 is unkwown => null

        // entity.SetSpawnerSource(EnumSpawnerSource.StaticSpawner, 0, entityGroup);
        /* Spawn */
        
        GameManager.Instance.World.SpawnEntityInWorld(entity);
        return entity;

    }

   
    // cf QuestActionSpawnEntitySDX



        
    public static IEnumerator StartSpawn(Emplacement place, string entityGroup) {
        Entity ent = Spawn(-1, place, entityGroup);
        yield return new WaitForSeconds(2.0f);
        // ent.SetDead();
        ent.Kill(DamageResponse.New(true)); // no exp, but Gore block
        yield return null;

      /*   entityGroup = "zombiesWasteland";
        for (int k = 0; k < 10; k++) {
            // int entityID = EntityGroups.GetRandomFromGroup(entityGroup); //  No overload for method 'GetRandomFromGroup' takes 1 arguments
            int entityID = 1; // TODO get id from name eg zombieboe in entity
            Entity ent = Spawn(entityID, new Vector3(place.position.x + k , place.position.y + k, place.position.z + k), entityGroup);
            yield return new WaitForSeconds(0.5f);
        }
        yield return null; */
    } 




    
    /* ******************** Motion ******************** */
     public static IEnumerator MvRotate(EntityPlayer player, Emplacement place) {
        Vector3i above = IntLine.Surface(place.position) + Vectors.Up;
        BlockValue existing = GameManager.Instance.World.GetBlock(above);
        for (int j = 0; j < 20; j++) {
            Debug.Log(String.Format("Block {0} rotation {1}", existing, existing.rotation));
            existing.rotation = (byte) ((existing.rotation + 1) % 7);              
            GameManager.Instance.World.SetBlockRPC(above, existing); // to refresh ??
            yield return new WaitForSeconds(2.0f);
        }
        yield return null;        
    }


    public static IEnumerator Fly(Entity entity, Emplacement place) {
        // return Move(entity, Vectors.Float.UnitY, 0.05f, 2f, 0);
        /// (0.1f, 4, 0) => un peu - 1/2 block
        /// (0.1f, 10, 0) => 1 block pour player, 4/5 pour Z !
        /// (0.1, 5) <=> 1 block ?
        /// (0.2, 5, interleave1) <=> 1 block aussi 
        /// Should I apply factor 0.5 by default ? on speed or frame ?
        return Move(entity, Vectors.Float.UnitY, 0.2f, 5, 0);
    }
    public static IEnumerator MvForward(Entity entity, Emplacement place) {
        // 0.2f, 10, 1 est tres lent        
        return Move(entity, place.direction.normalized, 0.5f, 20, 1);
    }

    public static IEnumerator FlyAll(EntityPlayer player, Emplacement place) {
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(place.position), Vector3.one * 2f * 10f),
                new List<Entity>());
        Debug.Log(String.Format("FlyAll {0} {1}", entitiesInBounds.Count, String.Join(", ", entitiesInBounds))); // String.Join(", ", names.ToArray());

        List<IEnumerator> enumerators = new List<IEnumerator>();
        foreach(Entity entity in entitiesInBounds) enumerators.Add(Move(entity, Vectors.Float.UnitY, 0.2f, 5, 0));
        return Merge(enumerators, 1.5f);
    }

    public static IEnumerator FlyAll2(EntityPlayer player, Emplacement place) {
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(place.position), Vector3.one * 2f * 10f),
                new List<Entity>());
        Debug.Log(String.Format("FlyAll {0} {1}", entitiesInBounds.Count, String.Join(", ", entitiesInBounds))); // String.Join(", ", names.ToArray());

        List<IEnumerator> enumerators = new List<IEnumerator>();
        foreach(Entity entity in entitiesInBounds) enumerators.Add(Move(entity, Vectors.Float.UnitY, 0.6f, 5, 1));
        return Merge(enumerators, 2f);
    }

    public static void FlyAll3(EntityPlayer player, Emplacement place) {
        /// 1/2 frames
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(place.position), Vectors.Float.One * 2f * 10f),
                new List<Entity>());
        Debug.Log(String.Format("FlyAll3 {0} {1}", entitiesInBounds.Count, String.Join(", ", entitiesInBounds))); // String.Join(", ", names.ToArray());
        
        List<IEnumerator> enumerators = new List<IEnumerator>();
        foreach(Entity entity in entitiesInBounds) Teleport(entity, Vectors.Float.UnitY, true);
    }

}