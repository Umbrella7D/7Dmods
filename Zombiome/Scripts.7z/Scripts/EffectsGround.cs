using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;

using itools;

public static class EffectsGround {

    
    

    public static void setBlockAt(Emplacement place, string block, Func<Vector3i, Block, int> setter) {
        // BlockValue blockvalue = new BlockValue((uint)Block.GetBlockByName(block, false).blockID); // could add damage ...
        // setter(place.position, blockvalue);
        setter(place.position, Block.GetBlockByName(block, false));
        
    }

     public static IEnumerator LineSurface(Emplacement place, string block, Func<Vector3i, Block, int> setter, IDictionary<string, string> attr_xml) {        
        Vector3i where = place.position;
        where = IntLine.Surface(where);
        Debug.Log("LineSurface ini" + where.ToString());
        Block blk = Block.GetBlockByName(block, false);           
        Vector3i above = Vectors.Up;

        IntLine traj = new IntLine(Vectors.ToFloat(place.position), Vectors.Float.UnitX);
        for (int k=0; k<10; k++) {
            where = traj.Get(k);
            Debug.Log("LineSurface " + k.ToString());
            // where = IntLine.Surface(where); // I don't need surface before orthogonal ... surface made after
            //Debug.Log("Line Surface " + where.ToString());
            IntLine orth = new IntLine(Vectors.ToFloat(where), Vectors.Float.UnitZ);
            for (int p=-5; p<6; p++) {
                Vector3i at = orth.Get(p);
                //Debug.Log("Line Surface inner " + p.ToString());
                at = IntLine.Surface(at);
                //Debug.Log("Line Surface inner at " + at.ToString());
                setter(at + above, blk);
            }
            // yield return new WaitForSeconds(1.0f);
            yield return new WaitForEndOfFrame();
        }  
        yield return null;    
    }
    


    public static string Get(IDictionary<string, string> attr_xml, string key, string def) { // UTILS
        if (attr_xml.ContainsKey(key)) return attr_xml[key];
        return def;
    }

    public static IEnumerator Peak(Emplacement place, string block, Func<Vector3i, Block, int> setter, IDictionary<string, string> attr_xml, bool reverse=true) {
        /* NB: yield at each block => extrapolateur lisee => repousse entities vers exterieur =>  moins de blocage, plus progressif croissance
        (contrairement a niveau par niveau => faire croitre points distants ds le mm yield)
        
        */
        // Debug.Log("test parse V3 " + StringParsers.ParseVector3("2,3,4", 0, -1).ToString());
        Vector3i pos = place.position;

        Vector3i size = Vectors.ToInt(StringParsers.ParseVector3(Get(attr_xml, "size", "1,8,1"), 0, -1));
        float pace = float.Parse(Get(attr_xml, "pace", "0.1"));
        bool collapse_once = bool.Parse(Get(attr_xml, "collapse_once", "false"));
        
        Block air = Block.GetBlockByName("air", false); // The air instance could prolly be shared ...
        Block blk = Block.GetBlockByName(block, false);

        // Start at -1 only if air below
        for(int h = -1; h <size.y; h++) {
            for(int e = -size.x; e <= size.x; e++) { // East
                for(int n = -size.z; n <= size.z; n++) { // North
                    Vector3i where = new Vector3i(pos.x+e, pos.y+h, pos.z+n); 
                    setter(where, blk);                                 
                }
                yield return new WaitForSeconds(pace);    
            }
            // 
        }
        if (! reverse) yield return null;
        // unset if exists
        for(int h = size.y-1; h >=-1; h--) { // when destroyed from below, collapse => destroy top to bottom
            for(int e = -size.x; e <= size.x; e++) { // East
                for(int n = -size.z; n <= size.z; n++) { // North
                    Vector3i where = new Vector3i(pos.x+e, pos.y+h, pos.z+n); 
                    BlockValue existing = GameManager.Instance.World.GetBlock(where);
                    if (existing.type == blk.blockID) { // .blockID
                        setter(where, air);
                        // yield return new WaitForSeconds(sleep);
                    }
                }
            }
            if (!collapse_once) yield return new WaitForSeconds(pace);            
        }
        yield return null;
    }

    public static IEnumerator PeakSetter(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        bool reverse = attr_xml["reverse"] != "";
        Vector3i pos = place.position;

        Vector3i size = Vectors.ToInt(StringParsers.ParseVector3(Get(attr_xml, "size", "1,8,1"), 0, -1));
        float pace = float.Parse(Get(attr_xml, "pace", "0.1"));
        bool collapse_once = bool.Parse(Get(attr_xml, "collapse_once", "false"));
        
        Block air = Block.GetBlockByName("air", false); // The air instance could prolly be shared ...
        Block blk = Block.GetBlockByName(attr_xml["value"], false);


        BlockSetter setter = new BlockSetter();
        setter.block = blk;
        setter.avoidBlock = attr_xml["erase"] == "";
        setter.avoidEntity = attr_xml["air_only"] != "";
        
        // Start at -1 only if air below
        for(int h = -1; h <size.y; h++) {
            for(int e = -size.x; e <= size.x; e++) { // East
                for(int n = -size.z; n <= size.z; n++) { // North
                    Vector3i where = new Vector3i(pos.x+e, pos.y+h, pos.z+n); 
                    // setter(where, blk); 
                    setter.Apply(where);                                             
                }
                setter.Push();
                yield return new WaitForSeconds(pace);    
            }
            // 
        }
        if (! reverse) yield return null;
        // unset if exists
        setter = new BlockSetter();
        setter.block = air;
        setter.avoidBlock = attr_xml["erase"] == "";
        setter.avoidEntity = attr_xml["air_only"] != "";
        for(int h = size.y-1; h >=-1; h--) { // when destroyed from below, collapse => destroy top to bottom
            for(int e = -size.x; e <= size.x; e++) { // East
                for(int n = -size.z; n <= size.z; n++) { // North
                    Vector3i where = new Vector3i(pos.x+e, pos.y+h, pos.z+n); 
                    BlockValue existing = GameManager.Instance.World.GetBlock(where);
                    if (existing.type == blk.blockID) { // .blockID // only erase the type I just inserted
                        // setter(where, air);
                        setter.Apply(where);    
                        // yield return new WaitForSeconds(sleep);
                    }
                }
            }
            if (!collapse_once) {
                setter.Push();
                yield return new WaitForSeconds(pace);
            }            
        }
        yield return null;
    }
    //public static IEnumerator Geyser(Emplacement place, string block, Func<Vector3i, Block, int> setter, IDictionary<string, string> attr_xml, bool reverse=true) {
        // TODO factoriser code pour avoir liste entités et les push
    //}



    public static System.Random Random = new System.Random();

    public static IEnumerator Chaos(Emplacement place, string block, Func<Vector3i, Block, int> setter, IDictionary<string, string> attr_xml) {        
        // ca fait rien pr l'instant. essayer de yield les sous call plutot que de les startcoroutine ??
        Vector3i inipos = place.position;
        for (int repeat=0; repeat< 5; repeat++) {            
            for (int clone=0; clone< 10; clone++) {
                Vector3i rdm = new Vector3i(Random.Next(-20,20), 0, Random.Next(-20,20));
                place.position = inipos + rdm; // [!}] in-place with past coroutine, should be ok (get pos at start, we reassign)
                IDictionary<string, string> copy = new Dictionary<string, string>(attr_xml);
                copy["size"] = String.Format("{0},{1},{2}", Random.Next(0,3), Random.Next(2,8), Random.Next(0,3));   
                GameManager.Instance.StartCoroutine(Peak(place, copy["value"], setter, copy));
                yield return new WaitForSeconds(0.3f);    
            }
            yield return new WaitForSeconds(4.0f);     
        }
    }

    public static void Ensevelir(Entity player, string block, Func<Vector3i, Block, int> setter, IDictionary<string, string> attr_xml) {   

        Entity target = player;


    }    
    

    public static IEnumerator Wave(Emplacement place, string block, Func<Vector3i, Block, int> setter, IDictionary<string, string> attr_xml) {
        /*  NB: position ou ray peuvent etre ds le vide. Il faut partir une case dessous et not erase ?
        */
        Debug.Log("test parse V3 " + StringParsers.ParseVector3("2,3,4", 0, -1).ToString());
        Vector3i pos = place.position;
        // size = E/W=largeur, hauteur, N/S profondeur (portee)
        Vector3i size = Vectors.ToInt(StringParsers.ParseVector3(Get(attr_xml, "size", "5,2,2"), 0, -1));
        Vector3 direction = place.direction;
        direction.y = 0.0f; // cancel H/L
        direction = direction.normalized;

        float pace = float.Parse(Get(attr_xml, "pace", "0.1"));
        bool collapse_once = bool.Parse(Get(attr_xml, "collapse_once", "false"));
        Block air = Block.GetBlockByName("air", false); // The air instance could prolly be shared ...
        Block blk = Block.GetBlockByName(block, false);

        int portee = 10;        

        Vector3 posf = Vectors.ToFloat(pos);

        for(int forward = 1; forward <=portee; forward++) {
            for(int width = -size.x; width <= size.x; width++) { 
                setter(Vectors.Toward(posf, direction, forward), blk);  // avant de la vague
                yield return new WaitForSeconds(pace);   
                setter(Vectors.Toward(posf, direction, forward-1), blk);
                setter(Vectors.Toward(posf, direction, forward-1) + Vectors.Up, blk); // if not exist material to speed up?
                yield return new WaitForSeconds(pace); 
                if(forward > 3) { // TODO: test existing ?
                    setter(Vectors.Toward(posf, direction, forward-1-2), air);
                    setter(Vectors.Toward(posf, direction, forward-1-2) + Vectors.Up, air);
                }                 
            }
        }
        yield return null;
    }





}