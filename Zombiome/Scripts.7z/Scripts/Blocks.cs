using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;

/*

Shift 1/2 bloc player : int / round ? position is "bottomleft", not center ?

*/
//player.world.gameManager.ItemDropServer 

// ItemClass

/*

terrSnow
terrBrownGrassDiagnoal (decoration !)
terrBurntForestGround
terrGravel (sentier)
terrForestGround
terrTallGrassDiagonal (c'estt un bloc - empeche de plaser - mais non collidant)
terrrAsphalt (Diresville), cconcretePlate, concretePillar100
cntBirdNest
terrDestroyedStone (wasteland
treeBurntMaple02
cinderBlock02
terrDesertGround
terrStone (dans le desert, un peu partout...)
terrDesertShrub (decoration vegatale)
rockResource
mushroom01 (grosses pierres, à spawn pour rouler depuis falaise)
flagstoneBlock
treeDeadPineLeaf
driftWood (bois desert)
orePotassiumNitrateBoulder
plantedAloe3Harvest
plantedYucca3Harvest
treeCactus04 : un petit
*/
// ya un moment ou on doit suivre le sol (peak, underwater, wave)


// GameManager.ShowTooltipWithAlert(_data.holdingEntity as EntityPlayerLocal, "You cannot use that at this time.", "ui_denied");


public static class Blocks {
    /* FIXME: I need unicize the above blocks and entities when applying push up, just before any yield 

    Block.HasTileEntity, OnBlockRemoved(), PlaceBlock()

    chunkSync3.StopStabilityCalculation = false;

    TileEntity.public static TileEntity Instantiate(TileEntityType type, Chunk _chunk)


    if (this.isMultiBlock && _blockValue.ischild)
	{
		Vector3i parentPos = this.multiBlockPos.GetParentPos(_blockPos, _blockValue);
		BlockValue block = _world.GetBlock(parentPos);
    
    */
    static bool ProtectLCB = true;
    public static BlockValue GenBlockValue(Block block) {
        /// Return a new BlockValue, or the "singleton" Air instance.
        if (block == null) return BlockValue.Air;
        return new BlockValue((uint) block.blockID);
    }

    public static int SetBlockAt(Vector3i where, Block block, IDictionary<string, string> attr_xml) {   
        BlockSetter setter = new BlockSetter();
        setter.block = block;
        setter.avoidBlock = attr_xml["erase"] == "";
        setter.avoidEntity = attr_xml["air_only"] != "";
        setter.Apply(where);
        setter.Push();
        return 18;
    }     

    public static int SetBlockAt_v0(Vector3i where, Block block, IDictionary<string, string> attr_xml) {        
        bool do_it = true;
        World world = GameManager.Instance.World;
        BlockValue existing = world.GetBlock(where);
        if (attr_xml["erase"] == "") {            
            do_it = (existing.type == BlockValue.Air.type);  
        }
        if (ProtectLCB) {
            int radius = 20;
            Vector3i dx = new Vector3i(radius, radius, radius);
            GameUtils.EPlayerHomeType hy = GameUtils.CheckForAnyPlayerHome(world, where -dx, where + dx); // TODO: unbound y
            if (hy != GameUtils.EPlayerHomeType.None) do_it = false;
        }
        if (do_it) {
            bool air_only = (attr_xml["air_only"] != "");
            /// FIXME si le block laissé n'est vertical stable, je pourrai pas empiler dessus (eg deco)
            /// FIXME: 
            if (air_only) {
                if (! IntersectsEntities(where, block) && ! IntersectTiles(where)) { // todo: and not intesrect block !!
                    // Debug.Log(String.Format(" air only go {0}{1}{2}", where, block, block.blockID));
                    // ne surtout pas pusher, je veux contourner ...
                    GameManager.Instance.World.SetBlockRPC(0, where, GenBlockValue(block));

                }
            } else {
                // Debug.Log(String.Format(" go {0}{1}{2}", where, block, block.blockID));
                if (block.blockID != 0) { // assume blockID 0 is Air
                    PushUpTiles(where); /// before to check 
                    GameManager.Instance.World.SetBlockRPC(0, where, GenBlockValue(block)); // "existoing" must be gotten before. TODO: returned value?
                    if (existing.type != BlockValue.Air.type) {
                        // PushUpBlock(where, existing);
                        PushUpBlockRec(where, existing);
                    } 
                    
                    PushUpEntities(where, block); 
                }
            }
        }
        return 18;
    }

    public static Bounds GetBounds(Vector3i where, Block block, float enlarge=0.05f) {   
        /// enlarge > 1 maybe prevents the falling mode to work
        Vector3 delta;     
        if (block.isMultiBlock) {
            // BoundsUtils.BoundsForMinMax(float mnx, float mny, float mnz, float mxx, float mxy, float mxz)
            delta = new Vector3(block.multiBlockPos.dim.x + enlarge, block.multiBlockPos.dim.y + enlarge, block.multiBlockPos.dim.z + enlarge);
        } else {
            delta = new Vector3(1f + enlarge, 1f + enlarge, 1f + enlarge);
            // Bounds bounds =  new Bounds(Vectors..ToFloat(where) + new Vector3(0f,1f,0f), Vector3.one * 2f);
        }
        Bounds bounds = new Bounds();
        bounds.SetMinMax(Vectors.ToFloat(where) - new Vector3(enlarge, enlarge, enlarge), Vectors.ToFloat(where) + delta);       
        return bounds;
    }

    public static bool IntersectsEntities(Vector3i where, Block block) {
        // FIXME: faster to loop and exit on first found !
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
            GetBounds(where, block),
            new List<Entity>());
        if (entitiesInBounds.Count > 0) Debug.Log(String.Format("IntersectsEntities: {0} {1}", entitiesInBounds.Count, entitiesInBounds));
        return entitiesInBounds.Count > 0;
    }
    public static bool IntersectTiles(Vector3i where) {
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        return (te != null);
    }

    public static void PushUpEntities(Vector3i where, Block block) {
        // FIXME: collision with multiple blocks (adjacent) will trigger multiple push up ...
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
            GetBounds(where, block),
            new List<Entity>());
        Debug.Log(String.Format("PushUpEntitiess: {0} {1}", entitiesInBounds.Count, string.Join(",", entitiesInBounds)));
        foreach(Entity entity in entitiesInBounds) {
            //Vector3 pos = entity.GetPosition();
            //pos.y = where.y + 1.0f;
            //entity.SetPosition(pos , false); // try _bUpdatePhysics=true
            EffectsEntity.Teleport(entity, Vectors.Float.UnitY, true);
        }        
    }
    public static void PushUpBlock(Vector3i where, BlockValue existing) {
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        if (te != null) Debug.Log(String.Format("PushUpBlock: {0} {1}", te, te.entityId));
        /// essayer aussi recursivement ..
        /// TODO: if there is place above ! + unicize
        Debug.Log(String.Format("PushUpBlock :{0} {1}", where, existing));
        GameManager.Instance.World.SetBlockRPC(0, where + Vectors.Up, existing);        
    }

    public static void PushUpBlockRec(Vector3i where, BlockValue existing) {
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        if (te != null) Debug.Log(String.Format("PushUpBlockRec: {0} {1}", te, te.entityId));
        World world = GameManager.Instance.World;          
        // while(true) {
        for (int k=0; k<10; k++) {            
            where = where + Vectors.Up;            
            BlockValue next = world.GetBlock(where);
            world.SetBlockRPC(0, where, existing); 
            existing = next;
            /// FIXME: not just air ? if not ground dont push ? (wht does set at surface does not go on surface ???)
            if (next.type == BlockValue.Air.type) return;
        }
    }

    public static void PushUpTiles(Vector3i where) {
        ///        
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        if (te != null) {
            Debug.Log(String.Format("PushUpTiles: {0} {1}", te, te.entityId));
            te.localChunkPos = te.localChunkPos + Vectors.Up; // not where+, this is relative to chunk !
            /// TODO: Trying no re-add see if lose state
            BlockSpawnUtils.ReAddTileEntity(te, where  + Vectors.Up);
            ///==> mais le trigger doit venir du OnBlockAdd de PushUpBlock.SetBlockRPC !!!
            // ==> Block.OnBlockAdded Vs. OnBlockAddedRaw, + autres choses (eg multiblock)
            // FIXME: manage chunk change
            // FIXME na pas l'air de marcher ...
        }
    }

    public static void AddBuffToRadius(String strBuff, Vector3 position, int Radius)
    {
        // If there's no radius, pick 30 blocks.
        if(Radius <= 0  )
            Radius = 30;

        World world = GameManager.Instance.World;
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(null, new Bounds(position, Vector3.one * Radius));
        if(entitiesInBounds.Count > 0)
        {
            for(int i = 0; i < entitiesInBounds.Count; i++)
            {
                EntityAlive entity = entitiesInBounds[i] as EntityAlive;
                if(entity != null)
                {
                    if(!entity.Buffs.HasBuff(strBuff))
                        entity.Buffs.AddBuff(strBuff);
                }
            }
        }

    }

}