using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;

using itools;

public static class EffectsCollapse {
    /*

    Options:
    - ground (water, traps)
    - recursion
    - size / depth (puis avant)
    - other content : Z, animal, torch, lights ...

    */
    
    public static void UnderCollapse(Emplacement place, string block, Func<Vector3i, Block, int> setter) {
        // BlockValue blockvalue = new BlockValue((uint)Block.GetBlockByName(block, false).blockID);
        Block blk = Block.GetBlockByName(block, false);
        Vector3i loc = place.position;
        int rad = 1;
        int depth = 4;
        for(int d = 0; d <depth; d++) { // depth
            for(int e = 0; e <rad; e++) { // East
                for(int n = 0; n <rad; n++) { // North
                    Vector3i where = new Vector3i(place.position.x+e, place.position.y-d, place.position.z+n);
                    setter(where, blk);
                }
            }
        }
        //https://7daystodie.com/forums/showthread.php?40959
        // https://7daystodie.com/forums/showthread.php?115649-c-Zombie-spawner&highlight=coroutine
    }

    
    public static void UnderCollapseBig(Emplacement place, string block, Func<Vector3i, Block, int> setter) {
        Vector3i pos = place.position;
        Block air = Block.GetBlockByName("air", false);
        Block blockvalue = Block.GetBlockByName(block, false);
        // BLOCK NE toujours (avec Math.round et for(int e = 0; e <1; e++)  )
        int rad = 4;
        int depth = 5;
        //int depth = 8;
        for(int d = 2; d <depth; d++) { // depth        
        //for(int d = -depth; d <depth; d++) { // depth // test ensevelir entity
            for(int e = -rad; e <=rad; e++) { // East
                for(int n = -rad; n <=rad; n++) { // North
                    Vector3i where = new Vector3i(pos.x+e, pos.y-d, pos.z+n);
                    setter(where, blockvalue);
                }
            }
        }
        //https://7daystodie.com/forums/showthread.php?40959
        // https://7daystodie.com/forums/showthread.php?115649-c-Zombie-spawner&highlight=coroutine
    }

    public static IEnumerator UnderCollapseGen(Emplacement place, string block, Func<Vector3i, Block, int> setter) {
        Vector3i pos = place.position;
        Block air = Block.GetBlockByName("air", false); // The air instance could prolly be shared ...
        Block blockvalue = Block.GetBlockByName(block, false);
        int rad = 1;
        int depth = 4;
        for(int d = 2; d <depth; d++) { // depth
            for(int e = 0; e <rad; e++) { // East
                for(int n = 0; n <rad; n++) { // North
                    Vector3i where = new Vector3i(pos.x+e, pos.y-d, pos.z+n); 
                    setter(where, blockvalue);              
                    yield return new WaitForSeconds(0.5f);
                }
            }
        }
        yield return null;
    }







}