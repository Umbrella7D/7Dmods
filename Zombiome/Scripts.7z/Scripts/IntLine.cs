using System;
using System.Linq;
using System.Collections.Generic;

using Unity;
using UnityEngine;


// Token: 0x02000126 RID: 294
public class IntLine {
	/// Line points with integer coordinates.
	/* I need 3D in case of diagonal digging. On surface, expect direction.y=0 or SI breaks */
	private Vector3 Center;
	private Vector3 Direction;
	private int IdxMin = -1;
	private int IdxOther1 = -1;
	private float Other1 = -1.0f;
	private int IdxOther2 = -1;
	private float Other2 = -1.0f;

	public IntLine(Vector3 center, Vector3 dir) {
		// TODO: guard error 0 dir
		this.Center = center;
		this.Direction = dir;
		// Console.WriteLine(String.Format("Line: {0} -> {1}", center, dir));
		IdxMin = 2;
		if (dir[0] >= dir[1] && dir[0] >= dir[2]) IdxMin = 0;
		else if (dir[1] >= dir[0] && dir[1] >= dir[2]) IdxMin = 1;
		IdxOther1 = (IdxMin + 1) % 3; // careful priorities : + < %
		IdxOther2 = (IdxMin + 2) % 3;
		// Console.WriteLine(String.Format("Idx: {0} {1} {2}", IdxMin, IdxOther1, IdxOther2));
		Other1 = dir[IdxOther1] / dir[IdxMin];
		Other2 = dir[IdxOther2] / dir[IdxMin];
		// Console.WriteLine(String.Format("Mult: {0} {1}", Other1, Other2));
	}
	public Vector3i Get(int k) {
		Vector3 result = new Vector3();
		result[IdxMin] = (int) Center[IdxMin] + k;
		result[IdxOther1] = (int) Center[IdxOther1] + Other1 * k;
		result[IdxOther2] = (int) Center[IdxOther2] + Other2 * k;
		return Vectors.ToInt(result);
	}
	public static List<Vector3i> Segment(Vector3 center, Vector3 dir, int start, int len) {
		IntLine l = new IntLine(center, dir);
		List<Vector3i> segment = new List<Vector3i>();
		for (int k=0; k<len; k++) segment.Add(l.Get(k));
		return segment;
	}

	public static void Main(string[] args)
    {	
		Vector3 c = new Vector3();
		c[1] = 1.0f;
		Vector3 d = new Vector3();
		d[0] = 2.0f;
		d[2] = 0.5f;
        IntLine l = new IntLine(c, d);
		foreach(int k in Enumerable.Range(-5,10)) { // slower than for ...
			Console.WriteLine(String.Format("{0} -> {1}", k, l.Get(k)));
		}
    }

	public static bool IsAboveSurface(Block block) {
		// if (bv.Equals(BlockValue.Air)) return true;
		// Debug.Log(String.Format("BlockValue air: {0} {1} ", BlockValue.Air, BlockValue.Air.Block.blockID)); // BlockValue.Air.Block.blockID == 0
		if (block.blockID == 0) return true; // should be equivalent to air
		if (block.IsDecoration) return true;
		if (block.Properties.Values.ContainsKey("Shape")) {
			if (block.Properties.Values["Shape"] =="Terrain") return false;
		}
		return true; // buildings 
	}
	public static bool IsGround(Block block) {
		if (block.Properties.Values.ContainsKey("Shape") && block.Properties.Values["Shape"] =="Terrain") return true;
		return false;
	}

    public static Vector3i Surface_V0(Vector3i start, int iniy = -1) {
		/// Get heigth of the surface.
		/// FIXME: stops at not IsAboveSurface instead of ground ?? 
        if (iniy >= 0) start.y = iniy;
        int y = start.y;
        start.y = 0;
        bool looking = true;
        while(looking) {
			Debug.Log("Surface Looking " + start.ToString());
            start.y = y;
            // if (_pos.y >= 0 && _pos.y < 256)
            BlockValue down = GameManager.Instance.World.GetBlock(start);
            // if (down.Equals(BlockValue.Air)) {
			if (down.Block.blockID == 0) {
                y = y-1;
            } else {
                BlockValue up = GameManager.Instance.World.GetBlock(start + Vectors.Up);
                if (IsAboveSurface(up.Block))  {
                    looking = false;
                    return start;
                } else y = y+1;
            }
            if (y<=0) {start.y = 0; return start;}
            if (y>=254) {start.y = 254; return start;}
        }
        return start; /// Should never come here
    }

	
    public static Vector3i Surface(Vector3i start, int iniy = -1) {
		/// Get heigth of the surface.
        if (iniy >= 0) start.y = iniy;
        int y = start.y;
        start.y = 0;
        bool looking = true;
		int dy = 0;

		start.y = y;            
        BlockValue current = GameManager.Instance.World.GetBlock(start);
		dy = (IsGround(current.Block)) ? 1 : -1;
		y = y + dy;
        while(looking) {
			// Debug.Log("Surface Looking " + start.ToString());
            start.y = y;            
            current = GameManager.Instance.World.GetBlock(start);
			if (IsGround(current.Block) && dy == -1) return start;
			else if (dy == 1) {
				start.y = y-1;
				return start;
			}
			y = y + dy;
            if (y<=0) {start.y = 0; return start;}
            if (y>=254) {start.y = 254; return start;}
        }
        return start; /// Should never come here
    }

}

// class Vector3 : List<float> {
// 	public Vector3() : base() {
// 		this.Add(0.0f); this.Add(0.0f); this.Add(0.0f);
// 	}
// 	public override String ToString() {
// 		return String.Format("({0},{1},{2})", base[0], base[1], base[2]);
// 	}
// }
// class Vector3i : List<int> {
// 	public Vector3i() : base() {
// 		this.Add(0); this.Add(0); this.Add(0);
// 	}
// 	public override String ToString() {
// 		return String.Format("({0},{1},{2})", base[0], base[1], base[2]);
// 	}
// }