//using System.Xml;
//using System;
//using System.Collections;
using UnityEngine;
using System.Collections.Generic;

//using Harmony;


//using System.Linq;
//using System.Reflection.Emit;

public class Emplacement {
    public Vector3i position;
    public Vector3 direction = new Vector3(0.0f, 1.0f, 0.0f);
    public Emplacement(Entity target, IDictionary<string, string> attr_xml) {
        Debug.Log("attr_xml 'at' = " + attr_xml["at"]);
        // position = Vectors.ToInt(target.position);
        position = World.worldToBlockPos(target.position);
        EntityPlayer player = target as EntityPlayer;
        // case of Z : get their target (player or direction or focus)
        if (player==null) return;
        if (attr_xml["at"] == "ray") position = Vectors.ToInt(BlockSpawnUtils.intersectLook(player));                    
        // if (attr_xml["at"] == "direction") direction = BlockSpawnUtils.directionLook(player);
        direction = BlockSpawnUtils.directionLook(player);

        if (attr_xml["th"] == "true") {
            int h = (int) target.world.GetTerrainHeight(position.x, position.z);
            Debug.Log(string.Format("GetTerrainHeight {0} => {1}", position, h));
            position.y = h;
        }
    }
}
