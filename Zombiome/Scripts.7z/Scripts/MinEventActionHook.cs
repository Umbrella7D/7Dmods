using System;
using System.Xml;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using System.Reflection;

using Harmony;
using System;
using System.Collections.Generic;

using Harmony;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using UnityEngine;

using itools;


// EntityPlayerLocal primaryPlayer = GameManager.Instance.World.GetPrimaryPlayer();


// this.local_sea_level = WeatherManager.SeaLevel();
// Weather manager get: eg GetCurrentSnowfallValue(), ...
// UpdateClouds -> SkyManager.SetMainCloudTexture(this.cloudTextures[0]);
		//SkyManager.SetBlendCloudTexture(this.cloudTextures[1]);
		//SkyManager.SetCloudTransition(WeatherManager.cloudTransition);

// public static WeatherManager.BiomeWeather currentWeather = null;
//  Start() 
// SpectrumControl.WeatherType enum
// WeatherManager.isSnowForceOn = false; gen snow ?

// (int)_chunk.GetTerrainHeight(i, j);
// dans World:
	/* public byte GetTerrainHeight(int worldX, int worldZ)
	{
		Chunk chunk = (Chunk)this.GetChunkSync(World.toChunkXZ(worldX), 0, World.toChunkXZ(worldZ));
		if (chunk != null)
		{
			return chunk.GetTerrainHeight(World.toBlockXZ(worldX), World.toBlockXZ(worldZ));
		}
		return 0;
	}
 */
// height <=> avec water (vs terrain), surement sans blocks genre construction!

public class MinEventActionHook : MinEventActionRemoveBuff {
    protected Type Deleguate = typeof(BlockEffects);
    protected IDictionary<string, string> attr_xml = new Dictionary<string, string>();
    public override bool ParseXmlAttribute(XmlAttribute _attribute)
    {
        // Maybe base.ParseXmlAttribute populates a list of attributes ? then just call it
        if (_attribute.Name != null) this.attr_xml[_attribute.Name] = _attribute.Value;
        base.ParseXmlAttribute(_attribute);   
        return true;    
    }

    private static void AssignFrom(string key, IDictionary<string, string> attr_xml, DynamicProperties from) {
        if (! attr_xml.ContainsKey(key)) {
            Debug.Log(String.Format("AssignFrom try property : {0} {1}", key, from));
            string value = null;
            from.ParseString(key, ref value);
            if (value != null) attr_xml[key] = value;
        }
    }

    private static string[] props = new string[6]{"effect", "ray", "at", "value", "erase", "th"};
    private static void FromItem(MinEventParams _params, IDictionary<string, string> attr_xml) {
        /// could be from buff !
        if (_params.ItemValue != null) {
            ItemClass item = ItemClass.list[_params.ItemValue.type];
            DynamicProperties dp = item.Properties;
            Debug.Log(String.Format("FromItem : {0} {1}", item, dp));
            // target effect ray
            // at value erase th
            foreach(string key in props) AssignFrom(key, attr_xml, dp);           
        }
    }

    public MinEventActionHook() : base() {
        /// Use MinEventParams.ItemValue to get missing attrs from parent ?
        /// Would ease my item creation

        // Debug.Log(String.Format("MinEventActionHook constructor")); // Why preconstructed before items are activated ? buff vs bufvalue ?

        attr_xml.Add("value", "");
        attr_xml.Add("at", "target"); // "target" or "ray" -> base position
        attr_xml.Add("gen", "spot"); // "spot" or "routine"
        attr_xml.Add("air_only", ""); // "" or "non empty" ->
        attr_xml.Add("erase", ""); // "" (dont erase) or "non empty" (do erase)  TODO: many filters ...

        attr_xml.Add("entityGroup", "ZombiesWasteland");
        attr_xml.Add("item", "meleeToolClawHammer");
        attr_xml.Add("effect", "__NOEFFECT__");
        attr_xml.Add("th", "__NOEFFECT__");
        attr_xml.Add("elastic", "__NOEFFECT__");        
    }    
    
    public void ExecutePlayer(EntityPlayer player) {       
        ShowObj.PrintAttributes(player);
        Vector3 pos = player.position;

        string attr = "";
        foreach(KeyValuePair<string, string> entry in attr_xml) attr = attr + String.Format(" {0}={1}", entry.Key, entry.Value);
        Debug.Log(String.Format("Spawn : Player={0} Attr={1}", player, attr));
        
        Emplacement place = new Emplacement(player as Entity, attr_xml);
        
        // if (attr_xml.ContainsKey("klass")) Type t = Type.GetType(attr_xml["klass"]);

        Type thisType = Deleguate;
        String effect = attr_xml["effect"];
        string[] split = attr_xml["effect"].Split(new char[]{'.'});
        if (split.Length >= 2) {
            Debug.Log(String.Format("ExecutePlayer : Klass={0} Effect={1}", split[0], split[1]));
            thisType = Type.GetType(split[0]);
            Debug.Log(String.Format("ExecutePlayer Klass={0}", thisType));
            effect = split[1];
        }
        MethodInfo theMethod = thisType.GetMethod(effect, BindingFlags.Static | BindingFlags.Public); // BindingFlags.Instance
        object[] args = new object[] {player, place, attr_xml};
        
        /// TODO: is casting returned object safer than declared type ?
        /// TODO: list of coroutine 
        if (theMethod.ReturnType == typeof(IEnumerator)) {
            GameManager.Instance.StartCoroutine((IEnumerator) theMethod.Invoke(this, args));
        } else {
            theMethod.Invoke(this, args);
        }
    }

    public override void Execute(MinEventParams _params) {
        FromItem(_params, this.attr_xml);
        Debug.Log(String.Format(" MEA Spawn.Execute: {0} {1} ", _params, _params.Self));
        ShowObj.PrintAttributes(_params);
        ShowObj.PrintAttributes(_params.Buff);
        ShowObj.PrintAttributes(_params.Buff.BuffClass);
        
       /* 
        MinEventParams. CachedEventParam=MinEventParams, TileEntity=,
        Self=[type=EntityPlayerLocal, name=s_h_a_i_o, id=1298],
        Other=, Others=,
        ItemValue=item=853 m=0 ut=0,
        ItemActionData=ItemActionEat+MyInventoryData, ItemInventoryData=ItemInventoryData, Position=(-331.7, 61.1, -1752.9),
        Transform=Player_1298 (UnityEngine.Transform),
        Buff=BuffValue, // acces au buf !
        BlockValue=id=18 r=0 d=0 m=0 m2=0 m3=0, POI=,
        Area=Center: (-331.7, 61.9, -1752.9), Extents: (0.3, 0.9, 0.3),
        Biome=desert,
        Tags=standing, idle, player, entity, human,
        DamageResponse=DamageResponse, ProgressionValue=,
        Seed=683647262, IsLocal=False,
        */

        // -> MinEventParams, EntityPLayerLocal[name="shaio", id=186]

        for (int i = 0; i < this.targets.Count; i++) {        
            EntityPlayer player = this.targets[i] as EntityPlayer;         
            if (player != null) this.ExecutePlayer(player);
        }            
    }
}