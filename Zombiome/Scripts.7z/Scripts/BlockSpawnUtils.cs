using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;

using itools;

/*

Shift 1/2 bloc player : int / round ? position is "bottomleft", not center ?

*/
//player.world.gameManager.ItemDropServer 

// gouffre water doit erase la dirt.sable (sinon pas de trou), mais pas les blocs plius compliqués 'lampadaire)
// ne passer en water que ce qui est air apres le trou ? water est une sorte d'air ... 

// ItemClass
public class BlockSpawnUtils {


    
    public static Vector3 intersectLook(EntityPlayer player) { //  'Entity' does not contain a definition for 'GetLookRay', so not for Zs ?
        // EntityPlayer player = GameManager.Instance.World.GetLocalPlayer(); // : 'World' does not contain a definition for 'GetLocalPlayer' 
        Ray lookRay = player.GetLookRay();
        if (Voxel.Raycast(GameManager.Instance.World, lookRay, 5000f, 65536, 64, 0f)) return Voxel.voxelRayHitInfo.hit.pos;
        else return player.position;
    }
    public static Vector3 directionLook(EntityPlayer player) {
        // Vector3 intersect = intersectLook(player);
        // return (intersect - player.position).normalized;
        Ray lookRay = player.GetLookRay();
        Vector3 dx = lookRay.direction;
        return dx.normalized;;
    }

    
    public static TileEntity GetTileEntity(Vector3i blockPos) {
        Chunk chunk = GameManager.Instance.World.GetChunkFromWorldPos(blockPos) as Chunk;
        TileEntity te = GameManager.Instance.World.GetTileEntity(chunk.ClrIdx, blockPos) as TileEntity;
        return te;
    }
    public static void ReAddTileEntity(TileEntity te, Vector3i blockPos) {
        World world = GameManager.Instance.World;
        Chunk chunk = world.GetChunkFromWorldPos(blockPos) as Chunk; // no TileEntity.position ?
        chunk.RemoveTileEntity(world, te);
        chunk.AddTileEntity(te);
    }

        // what is the type of BlockValue.Air; ??
        // Dans WinterModPrefab
        //static BlockValue snow = new BlockValue((uint)Block.GetBlockByName("terrSnow", false).blockID);
        //static BlockValue ice = new BlockValue((uint)Block.GetBlockByName("terrIce", false).blockID);
    
    /* ******************** Set Block ******************** */



 
                


    /* ******************** Other ******************** */
    public static void show_classes(EntityPlayer player) {  
        ShowObj.PrintClass(typeof(GameManager));
        ShowObj.PrintClass(GameManager.Instance);
        ShowObj.PrintClass(GameManager.Instance.World);

        ShowObj.PrintClass(typeof(Block));
        ShowObj.PrintClass(typeof(BlockValue));

        ShowObj.PrintClass(typeof(MinEventActionRemoveBuff));
        ShowObj.PrintClass(typeof(MinEventActionTargetedBase));
        ShowObj.PrintClass(typeof(MinEventActionHook));

        ShowObj.PrintClass(typeof(ItemStack));
        ShowObj.PrintClass(typeof(ItemClass));

        ShowObj.PrintClass(typeof(Entity));        
        ShowObj.PrintClass(typeof(EntityZombie));
        ShowObj.PrintClass(typeof(EntityPlayer));
        ShowObj.PrintClass(typeof(TileEntityPowered));

        ShowObj.PrintClass(typeof(EntityFactory));
        ShowObj.PrintClass(typeof(EntityClass));


        ShowObj.PrintClass(typeof(TileEntityType));
        ShowObj.PrintClass(typeof(XUiEvent_TileEntityDestroyed));

        ShowObj.PrintClass(typeof(Chunk));
        ShowObj.PrintClass(typeof(EnumAIDirectorChunkEvent)); // Heat
        ShowObj.PrintClass(typeof(IPowered));
        ShowObj.PrintClass(typeof(IWireNode));
        ShowObj.PrintClass(typeof(PowerItem));
        ShowObj.PrintClass(typeof(IRequirement));
        ShowObj.PrintClass(typeof(MinEventParams));
        ShowObj.PrintClass(typeof(EntityAlive));
        ShowObj.PrintClass(typeof(FastTags));
        ShowObj.PrintClass(typeof(StabilityViewer));
        ShowObj.PrintClass(typeof(BiomeParticleManager));
        ShowObj.PrintClass(typeof(EntityPlayerLocal));
        ShowObj.PrintClass(typeof(PersistentPlayerList));

        ShowObj.PrintClass(typeof(PersistentPlayerData));
        ShowObj.PrintClass(typeof(IBlockTool));
        ShowObj.PrintClass(typeof(MinEventTypes)); 
        ShowObj.PrintClass(typeof(PlayerActionsLocal)); 
         

        // ShowObj.PrintClass(typeof(SpawnPointList));
        
        // ShowObj.PrintClass(typeof(DamageSource)); // error !

        ShowObj.PrintClass(typeof(BuffValue));
        ShowObj.PrintClass(typeof(BiomeDefinition));
        ShowObj.PrintClass(typeof(DamageResponse));
        ShowObj.PrintClass(typeof(ProgressionValue));

        ShowObj.PrintClass(typeof(ItemClassTimeBomb));
        
        

         

        // ShowObj.PrintClass(typeof(ProjectileClass));   

        foreach (Type t in ShowObj.GetAllSubclassOf(typeof(Entity)))  Debug.Log(String.Format("Item class: {0} {1}", t.Name, t)); 
    }


    public static void test_block_around(EntityPlayer player) {      

        foreach (KeyValuePair<int, EntityClass> keyValuePair in EntityClass.list.Dict) {
            Debug.Log(String.Format("EntityClass --> {0} {1} {2}", keyValuePair.Key, keyValuePair.Value, keyValuePair.Value.entityClassName));            
        } // cool id, EntityClass, name of entity eg -570163696, animalCoyote or vehiculeMinibike...
        


        Vector3i dx = Vectors.UnitX;
        Vector3i dy = Vectors.UnitY;
        Vector3i dz = Vectors.UnitZ;
        Vector3i z = Vectors.Zero;
        List<Vector3i> shifts = new List<Vector3i>(){ z-dx, dx, z-dy, dy, z-dz, dz, z };

        BlockValue air = Block.GetBlockValue("Mair");
        Debug.Log(air.ToString());

        Vector3 ppos = player.position;
        Vector3i pos = Vectors.ToInt(ppos);
        Debug.Log(" Get block - " + player.ToString() + " " + ppos.ToString());
        foreach (Vector3i s in shifts) {
            BlockValue bv = GameManager.Instance.World.GetBlock(pos+s); 
            Block blc = Block.list[bv.type];

            String isTerrain = "";
            if (blc.Properties.Values.ContainsKey("Shape")) isTerrain = blc.Properties.Values["Shape"];

            List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(pos+s), Vector3.one * 2f),
                new List<Entity>());

            ShowObj.ShowAttributes(bv);
            ShowObj.ShowAttributes(blc);

            Vector3 normal = GameManager.Instance.World.GetTerrainNormalAt(pos.x, pos.z); //just like get height, produced by world gen, not updated by block alteration

            Vector3i parent = pos+s;
            if (blc.isMultiBlock) parent = new Vector3i(bv.parentx, bv.parenty, bv.parentz); // TODO: check Block.MultiBlockArray seems higher lvl , account rotation ...
            // NB the method get parent pos gives the opposite + pos => the block to really look at !
            Debug.Log(String.Format("   shift({0}) ->  bv={1} blc={2} nm={3} mat={4} -> {5} {6} {7} n={8} p = {9}",
                s,               
                bv, blc, blc.GetBlockName(), bv.Block.Properties.GetFloat("Material"),
                bv.type, entitiesInBounds, isTerrain, normal, 
                parent//blc.blockID            
            ));
            //Debug.Log(" Shape " + bv.Block.Properties.GetFloat("Shape"));
            //Debug.Log(" Texture " + bv.Block.Properties.GetFloat("Texture"));
            // Debug.Log(" Block " + bv.Block);
            //Debug.Log(" Properties " + bv.Block.Properties);

        }
        // Debug.Log(String.Format("GameUtils.WorldInfo.WoldSize {0}", GameUtils.WorldInfo.WoldSize));
        // Debug.Log(String.Format("GameUtils.WorldInfo.DayTimeToWorldTime() {0}", GameUtils.WorldInfo.DayTimeToWorldTime()));
        GameUtils.DrawCube(player.position, Color.red);
    }

   /*  public static void explore / test(EntityPlayer player, string item) {
    }
 */


    public static IEnumerator FireStorm(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Vector3i where = place.position;
        where = IntLine.Surface(where);
        Debug.Log("FireStorm ini" + where.ToString());

        IntLine traj = new IntLine(Vectors.ToFloat(place.position), Vectors.Float.UnitX); //east
        for (int k=0; k<15; k++) {
            where = traj.Get((k+1) * 5);
            where = IntLine.Surface(where);
            EffectsItem.spawnItem(player, "thrownAmmoMolotovInv", Vectors.ToFloat(where + Vectors.Up));
            yield return new WaitForEndOfFrame();
        }
        yield return null;
    }
    
    public static IEnumerator BoulderStorm(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Vector3i where = place.position;
        where = IntLine.Surface(where);
        Debug.Log("BoulderStorm ini" + where.ToString());         
        Vector3i above = Vectors.Up;

        IntLine traj = new IntLine(Vectors.ToFloat(place.position), Vectors.Float.UnitX); //east
        for (int k=0; k<15; k++) {
            where = traj.Get((k+1) * 5);
            where = IntLine.Surface(where);
            EffectsItem.spawnItem(player, "Boulder", Vectors.ToFloat(where) + new Vector3(0f,3f,0f), new Vector3((k % 3)*1f, 5f, (k/3)*1f));
            yield return new WaitForEndOfFrame();
        }
        yield return null;
    }

    public static IEnumerator CactusStorm(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Vector3i where = place.position;
        where = IntLine.Surface(where);
        Debug.Log("CactusStorm ini" + where.ToString());   
        Vector3i above = Vectors.Up;
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 

        IntLine traj = new IntLine(Vectors.ToFloat(place.position), new Vector3(1,0,0)); //east
        for (int k=0; k<15; k++) {
            where = traj.Get((k+1) * 5);
            where = IntLine.Surface(where);
            place.position = where + above; /// in place            
            setter(place.position, Block.GetBlockByName("treeCactus01", false));
            yield return new WaitForEndOfFrame();
        }
        yield return null;
    }
}

// ItemValue item->  Parcourt tous les 
/*
         public ItemValue IsConsumable(ItemValue item, String strSearchType)
    {
        DisplayLog(" IsConsumable() " + item.ItemClass.Name);
        DisplayLog(" Checking for : " + strSearchType);
        foreach (var Action in item.ItemClass.Actions)
        {
            if (Action is ItemActionEat)
            {
                DisplayLog(" Action Is Eat");
                foreach (var EffectGroup in item.ItemClass.Effects.EffectGroups)
                {
                    foreach (var TriggeredEffects in EffectGroup.TriggeredEffects)
                    {
                        MinEventActionModifyCVar effect = TriggeredEffects as MinEventActionModifyCVar;
                        if (effect == null)
                            continue;

                        DisplayLog(" Checking Effects");
                        if (strSearchType == "Food")
                        {
                            if ((effect.cvarName == "$foodAmountAdd") || (effect.cvarName == "foodHealthAmount"))
                                return item;


*/

/*
                Ray lookRay = GameManager.Instance.World.GetLocalPlayer().GetLookRay();
		if (Voxel.Raycast(GameManager.Instance.World, lookRay, 5000f, 65536, 64, 0f))
		{
			Vector3 tmp = Voxel.voxelRayHitInfo.hit.pos;
			string entityGroup = "ZombiesWasteland";
			long _chunkval = 0L;
			for (int spawnCount = 0; spawnCount < 10; spawnCount++)
			{
				Entity spawnEntity = EntityFactory.CreateEntity(EntityGroups.GetRandomFromGroup(entityGroup), tmp);
				spawnEntity.SetSpawnerSource(EnumSpawnerSource.StaticSpawner, _chunkval, entityGroup);
				GameManager.Instance.World.SpawnEntityInWorld(spawnEntity);
			}
		}
        

        public static void Spawn(ClientInfo _cInfo)
        {
            EntityPlayer _player = GameManager.Instance.World.Players.dict[_cInfo.entityId];
            Ray _position = _player.GetLookRay();

            if (Voxel.Raycast(GameManager.Instance.World, _position, 5000f, 65536, 64, 0f))
            {
                Vector3 tmp = Voxel.voxelRayHitInfo.hit.pos;
                string entityGroup = "ZombiesWasteland";
                long _chunkval = 0L;
                for (int spawnCount = 0; spawnCount < 10; spawnCount++)
                {
                    Entity spawnEntity = EntityFactory.CreateEntity(EntityGroups.GetRandomFromGroup(entityGroup), tmp);
                    spawnEntity.SetSpawnerSource(EnumSpawnerSource.StaticSpawner, _chunkval, entityGroup);
                    GameManager.Instance.World.SpawnEntityInWorld(spawnEntity);
                }
            }
        }

        foreach (KeyValuePair<string, int> kvp in pos)
                    {
                        Entities = GameManager.Instance.World.Entities.list;
                        string[] block_pos = kvp.Key.Split(',');
                        int.TryParse(block_pos[0], out int pos_x);
                        int.TryParse(block_pos[1], out int pos_y);
                        int.TryParse(block_pos[2], out int pos_z);

                        var vector3_pos = new Vector3((float)pos_x, (float)pos_y, (float)pos_z);

                        World world = GameManager.Instance.World;
                        int entityID = EntityGroups.GetRandomFromGroup("Z_Spawner");

                        if (entityID > 0)
                        {
                            Entity spawnEntity = EntityFactory.CreateEntity(entityID, vector3_pos);
                            spawnEntity.SetSpawnerSource(EnumSpawnerSource.Dynamic);
                            world.SpawnEntityInWorld(spawnEntity);
                        }
                        Thread.Sleep(5000);
                    }

        */

// https://7daystodie.com/forums/showthread.php?41993-MOD-Rayvator-Build-Elevator-from-bedrock-to-build-height-Add-Remove-levels&highlight=overload+method+%27GetRandomFromGroup%27+takes+arguments
// Eleveator

/*

    public static float GetCVarValue(int EntityID, string strCvarName)
    {
        float value = 0f;
        EntityAliveSDX myEntity = GameManager.Instance.World.GetEntity(EntityID) as EntityAliveSDX;
        if(myEntity)
        {
            if(myEntity.Buffs.HasCustomVar(strCvarName))
                value = myEntity.Buffs.GetCustomVar(strCvarName);
        }
        return value;
    }

    */