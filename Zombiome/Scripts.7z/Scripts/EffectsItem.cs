using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;

using itools;

public static class EffectsItem {

    

    /* ******************** Item ******************** */
    public static void spawnItem(EntityPlayer player, string item) {
        //EntityPlayerLocal player = GameManager.Instance.World.GetPrimaryPlayer();
        // if(entityAlive is EntityPlayerLocal)

        // base.ItemController in ItemActionEntryResharpenSDX : BaseItemActionEntry

        // using System;using System.Globalization;using System.Xml;using UnityEngine;

        // item = "meleeToolClawHammer";
        ItemStack itemStack = new ItemStack(ItemClass.GetItem(item, false), 1); // this.CreateItemCount
        //player.world.gameManager.ItemDropServer(itemStack, player.GetPosition(), Vector3.zero, -1, 60f, false);

        //invData.gameManager.ItemDropServer(new ItemStack(holdingEntity.inventory.holdingItemItemValue, 1), vector, Vector3.zero,
        //        lookVector * _actionData.m_ThrowStrength, holdingEntity.entityId, 60f, true, -1);
		

/*         ItemDropServer(
            ItemStack _itemStack,
            Vector3 _dropPos, Vector3 _randomPosAdd, Vector3 _initialMotion,
            int _entityId = -1,
            float _lifetime = 60f
             bool _bDropPosIsRelativeToHead = false, int _clientInstanceId = 0); */
        

        player.world.gameManager.ItemDropServer(
            itemStack,
            player.GetPosition() + new Vector3(1.0f,0.2f,0.0f),  Vector3.zero, new Vector3(1,-1,0),
            player.entityId, // -1 plante (pour gagner XP ?)
            1f,
            false,
            0);




        //if (!LocalPlayerUI.GetUIForPlayer(player).xui.PlayerInventory.AddItem(itemStack, true)) // Argument 1: cannot convert from 'EntityPlayer' to 'EntityPlayerLocal'
        //{
        //    player.world.gameManager.ItemDropServer(itemStack, player.GetPosition(), Vector3.zero, -1, 60f, false);
        //}
    }


    public static void spawnItem(EntityPlayer player, string item, Vector3 position) {spawnItem(player, item, position, -Vectors.Float.UnitY);}
    public static void spawnItem(EntityPlayer player, string item, Vector3 position, Vector3 motion) {
        ItemStack itemStack = new ItemStack(ItemClass.GetItem(item, false), 1); // this.CreateItemCount
        player.world.gameManager.ItemDropServer(
            itemStack,
            position + new Vector3(0.0f,0.2f,0.0f), // initial pos
            Vector3.zero, /// rdm
            motion, ///  _initialMotion
            player.entityId, // -1 plante (pour gagner XP ?)
            1f,
            false,
            0
        );
    }

    public static void EmulateMolotov(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        /// Explosion uses an altered molotovAmmo : sets no buff (would give xp) + empty mesh (looks like cloth, can we do better ?) 
        spawnItem(player, "thrownAmmoMolotovInv", Vectors.ToFloat(place.position));
        /// Buff part. Not managed by Projectile (would give XP).
        int radius = 10;
        Blocks.AddBuffToRadius("buffBurningMolotov", Vectors.ToFloat(place.position), radius); // "buffShocked"
        player.Buffs.CVars["buffBurningMolotovDuration"] = 10;
        /// maybe setting controler to nearest Z is enough to circumvent xp issue
    }   


    public static void Explosion(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        /// effet graphique seul (mm si molo contient des degats, ils concernent le onImpact, pas l'explosion elle meme)
        ///
        ItemClass itemClass = ItemClass.GetItemClass("thrownAmmoMolotovCocktail", false);
        Debug.Log(String.Format("Explosion --> {0}", itemClass));   
        // GameManager.Instance.ExplosionServer(0, Vectors.ToFloat(place.position), place.position, Quaternion.identity, new ExplosionData(itemClass.Properties), player.entityId, 0.1f, false, null); // try -1
        GameManager.Instance.ExplosionServer(0, Vectors.ToFloat(place.position), place.position, Quaternion.identity, new ExplosionData(itemClass.Properties), -1, 0.1f, false, null);
        // try in the air
        // altérer particule pour toutes les essayer
    }   
    
    public static IEnumerator ExplosionChain(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        /// effet graphique seul (mm si molo contient des degats, ils concernent le onImpact, pas l'explosion elle meme)
        ///
        ItemClass itemClass = ItemClass.GetItemClass("thrownAmmoMolotovCocktail", false);
        DynamicProperties baseProps = itemClass.Properties;
        ExplosionData ed = new ExplosionData(baseProps);
        Debug.Log(String.Format("ExplosionChain --> {0}", itemClass));   
        
        /*
        1: petite explo
        2-5 : explo de plus en plus grand + fumée
        6 : explo + un peu de flamme
        7: vomit, 8: gore block explo
        9: like 6

        10-19: avec un peu de flammes (bidons détruit: todo bombe !)
        */

        for (int k=1; k<20; k++) {
            //DynamicProperties props = new DynamicProperties();
            //props.CopyFrom(baseProps);
            //props.Set
            // DataItem<int> data = props.GetDataItemInt("Explosion.ParticleIndex");
            // data.Value = k+1; // modifies in place the content ...
            //props.Values["Explosion.ParticleIndex"] // is that parsed as "ParticleIndex"
            ed.ParticleIndex = k+15; // new DataItem<int>(k+1);
            Vector3i where = place.position + new Vector3i(0, 0, 3*k); ///N
            GameManager.Instance.ExplosionServer(0, Vectors.ToFloat(where), where, Quaternion.identity, ed, player.entityId, 0.1f, false, null); // try -1
            yield return new WaitForSeconds(4.0f); 
        }

         // try in the air
        // altérer particule pour toutes les essayer
    }  


    public static IEnumerator Particle(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Vector3 pos = Vectors.ToFloat(place.position);
        float lightValue = GameManager.Instance.World.GetLightBrightness(place.position) / 2f;
        ParticleEffect pe = new ParticleEffect("electric_fence_sparks", pos, lightValue, new Color(1f, 1f, 1f, 0.3f), "electric_fence_impact", null, false);
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);
         pe = new ParticleEffect("electric_fence_sparks", pos + 4 * Vectors.Float.One, lightValue, new Color(1f, 0f, 1f, 0.3f), "electric_fence_impact", null, false);
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);
         pe = new ParticleEffect("electric_fence_sparks", pos + 8 * Vectors.Float.One, lightValue, new Color(1f, 1f, 0f, 0.3f), "electric_fence_impact", null, false);
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);

        pe = new ParticleEffect("smoke", pos, lightValue, new Color(1f, 1f, 0f, 0.3f), "electric_fence_impact", null, false); //2 e string is sound
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);

        pe = new ParticleEffect("big_smoke", pos + 3 * Vectors.Float.One, lightValue, new Color(1f, 1f, 0f, 0.3f), "electric_fence_impact", null, false); //2 e string is sound
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);

         pe = new ParticleEffect("ember_pile", pos + 6 * Vectors.Float.One, lightValue, new Color(0f, 1f, 1f, 0.3f), "electric_fence_impact", null, false); //2 e string is sound
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);

        pe = new ParticleEffect("hot_embers", pos, lightValue, new Color(1f, 0f, 1f, 0.3f), "electric_fence_impact", null, false); //2 e string is sound
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);

        pe = new ParticleEffect("torch_wall", pos + 3 * Vectors.Float.One, lightValue, new Color(0f, 1f, 1f, 0.3f), "electric_fence_impact", null, false); //2 e string is sound
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return new WaitForSeconds(1f);

        pe = new ParticleEffect("campfire", pos + 6 * Vectors.Float.One, lightValue, new Color(1f, 0f, 1f, 0.3f), "electric_fence_impact", null, false); //2 e string is sound
        GameManager.Instance.SpawnParticleEffectServer(pe, -1);
        yield return null;
    }

}