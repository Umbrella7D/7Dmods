using System;
using System.Xml;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using System.Reflection;

using Harmony;
using System;
using System.Collections.Generic;

using Harmony;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using UnityEngine;

using itools;

/*
Shift 1/2 bloc player : int / round ? position is "bottomleft", not center ?
*/


/* MinEventParams _params

- _params.Self.EntityName , _params.Self.factionId, _params.Self.isEntityRemote
EntityPlayerLocal entityPlayer = _params.Self as EntityPlayerLocal;

MinEventActionNotifyTeamAttack : MinEventActionTargetedBase et MinEventActionNotifyTeamAttack : MinEventActionBase

MinEventActionCreateItemSdx
*/
//
/*     public override bool ParseXmlAttribute(XmlAttribute _attribute)
    {
        // Maybe base.ParseXmlAttribute populates a list of attributes ? then just call it
        if (_attribute.Name != null) { 
            // Debug.Log(" ParseXmlAttribute " + this.ToString() + " ? " + _attribute.Name);
            foreach(string key in this.attr_xml.Keys) {
                if (_attribute.Name == key ) {
                    this.attr_xml[key] = _attribute.Value;
                    // Debug.Log(" ParseXmlAttribute found " + this.ToString() +  " ? " + _attribute.Name + " -> " + _attribute.Value);                                        
                    return true;
                }
            }            
        }
        // Debug.Log(" Parsed on " + this.ToString() +  ":" + this.attr_xml);    
        return base.ParseXmlAttribute(_attribute);        
    } */

 // MinEventActionRemoveBuff (implementend as <triggered_effect trigger="onSelfPrimaryActionEnd") { // MinEventActionTargetedBase
    // This loops through all the targets, refreshing the quest. 
    //  <triggered_effect trigger="onSelfBuffStart" action="PumpQuestSDX, Mods" target="self"  />

        /* pos float (-21.0, 61.1, 15.8) en 16N 21W 61E
        <=> (E/W, U/L, N/S)
        <=> (>0 to East, >0 to sky, >0 to N)
        Bedrock at 0 !

        */

/* 
    public virtual void collapse(EntityPlayer player, Vector3 pos, IDictionary<string, string> attr_xml) {
        // if (this.attr_xml["at"] == "ray") pos = BlockSpawnUtils.intersectLook(player);

        // Func<Vector3i, Block, int> setter = this.SetBlockAt;
        // BlockSpawnUtils.UnderCollapse(pos, this.attr_xml["value"], setter);
        BlockEffects.name2action[attr_xml["effect"]](player, pos, attr_xml);
    } */


        // overloaded Block:
/*             private void EventData_Event(object obj)
            {
                #region EventData_Event
                World world = GameManager.Instance.World;
                object[] array = (object[])obj;
                int clrIdx = (int)array[0];
                BlockValue blockValue = (BlockValue)array[1];
                Vector3i vector3i = (Vector3i)array[2];
                BlockValue block = world.GetBlock(vector3i);
                EntityPlayerLocal entityPlayerLocal = array[3] as EntityPlayerLocal;

                TileEntityLootContainer tileEntityLootContainer = world.GetTileEntity(clrIdx, vector3i) as TileEntityLootContainer;
                if (tileEntityLootContainer != null)
                {
                    world.GetGameManager().DropContentOfLootContainerServer(blockValue, vector3i, tileEntityLootContainer.entityId);
                }

                // Pick up the item and put it inyor your inventory.
                LocalPlayerUI uiforPlayer = LocalPlayerUI.GetUIForPlayer(entityPlayerLocal);
                ItemStack itemStack = new ItemStack(block.ToItemValue(), 1);
                if (!uiforPlayer.xui.PlayerInventory.AddItem(itemStack, true))
                {
                    uiforPlayer.xui.PlayerInventory.DropItem(itemStack);
                }
                world.SetBlockRPC(clrIdx, vector3i, BlockValue.Air);

                #endregion
            } */





      //  var numbersAndWords = numbers.Zip(words, (n, w) => new { Number = n, Word = w });
      //foreach(var nw in numbersAndWords) Console.WriteLine(nw.Number + nw.Word);

        

        // public override int OnBlockDamaged(WorldBase _world, int _clrIdx, Vector3i _blockPos, BlockValue _blockValue, int _damagePoints, int _entityIdThatDamaged, bool _bUseHarvestTool, bool _bByPassMaxDamage, int _recDepth)
        // _world.SetBlockRPC(_clrIdx, _blockPos, _blockValue);
        // _world.SetBlockRPC(_clrIdx, _blockPos, BlockValue.Air);
        // _world.SetBlockRPC(_clrIdx, _blockPos, downgrade, list[downgrade.type].Density);
        // _world.SetBlockRPC(_clrIdx, _blockPos, downgrade);
        
        // this.theEntity.world.SetBlockRPC(sanitationBlock, Block.GetBlockValue(this.strSanitationBlock, false));
        // 