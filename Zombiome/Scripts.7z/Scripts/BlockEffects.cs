using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;

/*

Shift 1/2 bloc player : int / round ? position is "bottomleft", not center ?

*/
//player.world.gameManager.ItemDropServer 

// ItemClass

/*

terrSnow
terrBrownGrassDiagnoal (decoration !)
terrBurntForestGround
terrGravel (sentier)
terrForestGround
terrTallGrassDiagonal (c'estt un bloc - empeche de plaser - mais non collidant)
terrrAsphalt (Diresville), cconcretePlate, concretePillar100
cntBirdNest
terrDestroyedStone (wasteland
treeBurntMaple02
cinderBlock02
terrDesertGround
terrStone (dans le desert, un peu partout...)
terrDesertShrub (decoration vegatale)
rockResource
mushroom01 (grosses pierres, à spawn pour rouler depuis falaise)
flagstoneBlock
treeDeadPineLeaf
driftWood (bois desert)
orePotassiumNitrateBoulder
plantedAloe3Harvest
plantedYucca3Harvest
treeCactus04 : un petit
*/
// ya un moment ou on doit suivre le sol (peak, underwater, wave)


// GameManager.ShowTooltipWithAlert(_data.holdingEntity as EntityPlayerLocal, "You cannot use that at this time.", "ui_denied");


// Get block retourne le m BlockValue (id) pour chaque bloc différent -> ne push qu'une seule fois
// idem entities ?
//

// can I do while() {set block, yield frame, if isStuck push up} ?
// isStuck=> push at every frame might be enough (instead of +1 suddenly before yield)


/* TODO:
fissures, caves, fissures inversées (wave persistante), geyser

Lighn storm

swnofall + random falling blocks


*/


public static class BlockEffects {
    public static void test_block_around(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        
        BlockSpawnUtils.test_block_around(player);
    }

    public static void show_classes(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        
        BlockSpawnUtils.show_classes(player);
    }

     public static IEnumerator line_surface(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Debug.Log(string.Format("line_surface {0} {1} {2}", player, place, attr_xml));
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml);
        Debug.Log(string.Format("line_surface {0} {1} {2}", setter, place.position, attr_xml["value"]));
        // GameManager.Instance.StartCoroutine(EffectsGround.LineSurface(place, attr_xml["value"], setter, attr_xml));
        return EffectsGround.LineSurface(place, attr_xml["value"], setter, attr_xml);
    }
    public static IEnumerator line_surfaceOV(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        /// compare timing
        Debug.Log(string.Format("line_surface {0} {1} {2}", player, place, attr_xml));
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt_v0(_where, _block, attr_xml);
        Debug.Log(string.Format("line_surface {0} {1} {2}", setter, place.position, attr_xml["value"]));
        // GameManager.Instance.StartCoroutine(EffectsGround.LineSurface(place, attr_xml["value"], setter, attr_xml));
        return EffectsGround.LineSurface(place, attr_xml["value"], setter, attr_xml);
    }

    


    public static void spawn_at(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        /// does not use surface, but intersect of ray often matches surface !
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        // Blocks.SetBlockAt(place,  attr_xml["value"], setter);
        setter(place.position, Block.GetBlockByName(attr_xml["value"], false));
    }

    public static void spawn_above(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        // Blocks.SetBlockAt(place,  attr_xml["value"], setter);
        setter(place.position + Vectors.Up, Block.GetBlockByName(attr_xml["value"], false));
    }

    public static void trou(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {        
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        EffectsCollapse.UnderCollapse(place, attr_xml["value"], setter);
    }

    public static void gouffre(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        EffectsCollapse.UnderCollapseBig(place,  attr_xml["value"], setter);
    }
    public static IEnumerator spawngen(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        // GameManager.Instance.StartCoroutine(EffectsCollapse.UnderCollapseGen(place, attr_xml["value"], setter));
        return EffectsCollapse.UnderCollapseGen(place, attr_xml["value"], setter);
    }

    public static IEnumerator peak(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        // BlockSpawnUtils.Peak(pos,  attr_xml["value"], setter);
       return EffectsGround.Peak(place, attr_xml["value"], setter, attr_xml);
    }

    public static IEnumerator chaos(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        // BlockSpawnUtils.Peak(pos,  attr_xml["value"], setter);
        return EffectsGround.Chaos(place, attr_xml["value"], setter, attr_xml);
    }
    public static IEnumerator wave(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        // BlockSpawnUtils.Peak(pos,  attr_xml["value"], setter);
        return EffectsGround.Wave(place, attr_xml["value"], setter, attr_xml);
    }
    public static IEnumerator chute(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        Func<Vector3i, Block, int> setter = (_where, _block) => Blocks.SetBlockAt(_where, _block, attr_xml); 
        return EffectsGround.Peak(place, attr_xml["value"], setter, attr_xml, false);
    }



    public static void spawn_entity(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
         EffectsEntity.Spawn(1, place, attr_xml["value"]); //NPE, items aussi
    }
    public static IEnumerator spawn_entity_gen(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        return EffectsEntity.StartSpawn(place, attr_xml["value"]);
    }
   

  
    public static void spawn_item(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        EffectsItem.spawnItem(player, attr_xml["item"]);
    }

    public static void AsMolotov(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        EffectsItem.EmulateMolotov(player, place, attr_xml);
    }



    public static IEnumerator Particle(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        return EffectsItem.Particle(player, place, attr_xml);
    }


    public static void Explosion(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        EffectsItem.Explosion(player, place, attr_xml);
    }

    public static IEnumerator ExplosionChain(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        return EffectsItem.ExplosionChain(player, place, attr_xml);
    }
    

    public static IEnumerator FireStorm(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        return BlockSpawnUtils.FireStorm(player, place, attr_xml);
    }

    public static IEnumerator CactusStorm(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        return BlockSpawnUtils.CactusStorm(player, place, attr_xml);
    }
    
    public static IEnumerator BoulderStorm(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        return BlockSpawnUtils.BoulderStorm(player, place, attr_xml);
    }



    public static void tp_to(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        // access player.width instead of player.get_width()
        Console.WriteLine(String.Format("Size: {0} {1} {2}", player.width​,player.depth,player.height ));  // 'Entity.width.get': cannot explicitly call operator or accessor
        Console.WriteLine(String.Format("Pos: {0}", player.GetBlockPosition​() ) );
        // Console.WriteLine("Adjacent:");
        // foreach(Vector3i adj in player.adjacentPositions) Console.WriteLine(adj.ToString());
        player.SetPosition(player.GetPosition() + new Vector3(2,2,2) , false); // TODO test false
    }

    public static void set_pos(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        // access player.width instead of player.get_width()
        //Console.WriteLine(String.Format("Size: {0} {1} {2}", player.width​,player.depth,player.height ));  // 'Entity.width.get': cannot explicitly call operator or accessor
        //Console.WriteLine(String.Format("Pos: {0}", player.GetBlockPosition​() ) );
        // Console.WriteLine("Adjacent:");
        // foreach(Vector3i adj in player.adjacentPositions) Console.WriteLine(adj.ToString());
        //player.SetPosition(player.GetPosition() + new Vector3(2,2,2) , false); // TODO test false
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(place.position), Vector3.one * 2f * 10f),
                new List<Entity>());
                // Array.ForEach(yourArray, Console.WriteLine);
        Debug.Log(String.Format("entitiesInBounds {0} {1}", entitiesInBounds.Count, String.Join(", ", entitiesInBounds))); // String.Join(", ", names.ToArray());
        foreach(Entity entity in entitiesInBounds) entity.SetPosition(entity.GetPosition() + new Vector3(2,2,2) , false); // TODO test false
    }
    public static void test_push(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        // player.PhysicsPush(new Vector3(5,5,0), player.GetPosition() - new Vector3(0,1,0)); // player.GetPosition() - new Vector3(2,2,0));

        /* player.​Move​(new Vector3(2f,0f,0f), true,  20.0f, 40.0f);
        player.​Move​(new Vector3(0f,0f,1f), false,  20.0f, 40.0f);
        player.​Move​(new Vector3(0f,1f,1f), false,  20.0f, 40.0f);
        player.​Move​(new Vector3(0f,1f,1f), true,  20.0f, 40.0f);
        player.velocityChanged = true;
        */

        // player.​MakeMotionMoveToward​(1.0f, 1.0f, 5.0f, 50.0f);
        // player.StartJump();
        // player.Groan();
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(place.position), Vector3.one * 2f * 10f),
                new List<Entity>());
                // Array.ForEach(yourArray, Console.WriteLine);
        Debug.Log(String.Format("entitiesInBounds {0} {1}", entitiesInBounds.Count, String.Join(", ", entitiesInBounds))); // String.Join(", ", names.ToArray());
        foreach(Entity entity in entitiesInBounds) {
            entity.​Move​(new Vector3(0f,0f,1f), false,  20.0f, 40.0f);
            if (entity as EntityPlayer != null)
            ((EntityPlayer) entity ).​MakeMotionMoveToward​(1.0f, 1.0f, 5.0f, 50.0f);
        }

    }
    public static void test_fly(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        //player.​SetVelocity​(new Vector3(20,0,0));        
        //player.speedVertical = (float) 10.0;
        //player.velocityChanged = true;

        // player.motion = new Vector3(2,2,0);
        player.moveDirection = new Vector3(2,2,0); // PlayerMoveControler => EntityAlive.moveDirection
    }

    public static void forward(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(place.position), Vector3.one * 2f * 10f),
                new List<Entity>());
                // Array.ForEach(yourArray, Console.WriteLine);
        Debug.Log(String.Format("entitiesInBounds {0} {1}", entitiesInBounds.Count, String.Join(", ", entitiesInBounds))); // String.Join(", ", names.ToArray());
        foreach(Entity entity in entitiesInBounds) GameManager.Instance.StartCoroutine(EffectsEntity.MvForward(entity, place));
    }
    public static void levitate(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {   
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
                new Bounds(Vectors.ToFloat(place.position), Vector3.one * 2f * 10f),
                new List<Entity>());
                // Array.ForEach(yourArray, Console.WriteLine);
        Debug.Log(String.Format("entitiesInBounds {0} {1}", entitiesInBounds.Count, String.Join(", ", entitiesInBounds))); // String.Join(", ", names.ToArray());
        foreach(Entity entity in entitiesInBounds) GameManager.Instance.StartCoroutine(EffectsEntity.Fly(entity, place));     
        // GameManager.Instance.StartCoroutine(EffectsEntity.Fly(player, place));
    }

    public static IEnumerator rotate(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {        
       return EffectsEntity.MvRotate(player, place);
    }

    public static IEnumerator FlyAll(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {        
        return EffectsEntity.FlyAll(player, place);
    }
    public static IEnumerator FlyAll2(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {        
        return EffectsEntity.FlyAll2(player, place);
    }
    public static void FlyAll3(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {        
        EffectsEntity.FlyAll3(player, place);
    }

    public static void Rain(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        // Blocks.AddBuffToRadius("buffLight", Vectors.ToFloat(place.position), 2);
        WeatherManager.forceRain = Mathf.Clamp01(1.0f);
    }


    

    /*
    UnityEngine.Vector3 motion
    System.Boolean velocityChanged
    System.Single speedStrafe
    System.Single speedForward
    System.Single speedVertical
    System.Int32 MovementState
    System.Single projectedMove
    Void OnUpdatePosition(Single)
    Void CheckPosition()
    Void OnUpdateEntity()
    Vector3i GetBlockPosition()
    UnityEngine.Vector3 GetPosition()
    Void PhysicsPush(UnityEngine.Vector3, UnityEngine.Vector3)

    Void SetPosition(UnityEngine.Vector3, Boolean)
    Void SetRotationAndStopTurning(UnityEngine.Vector3)
    */
    
    
	public static Transform instantiateProjectile(ItemActionData _actionData, Vector3 _positionOffset = default(Vector3))
	{	
        return null;
        /* itemActionDataLauncher.projectileInstance.Add(this.instantiateProjectile(_actionData, default(Vector3)));




		ItemClass forId = ItemClass.GetForId(ItemClass.GetItem(this.MagazineItemNames[(int)holdingItemItemValue.SelectedAmmoTypeIndex], false).type);
		if (forId == null) return null;

		ItemActionLauncher.ItemActionDataLauncher itemActionDataLauncher = (ItemActionLauncher.ItemActionDataLauncher)_actionData;
		int entityId = _actionData.invData.holdingEntity.entityId;
		ItemValue itemValue = new ItemValue(forId.Id, false);
		Transform transform = forId.CloneModel(_actionData.invData.world, itemValue, Vector3.zero, null, false, false, 0L);
		Transform transform2 = null; // itemActionDataLauncher.projectileJoint;
		if (transform2 == null)
		{
			transform2 = ((itemActionDataLauncher.invData.holdingEntity.emodel.avatarController != null) ? itemActionDataLauncher.invData.holdingEntity.emodel.GetRightHandTransform() : null);
		}
		if (transform2 != null)
		{
			transform.parent = transform2;
			transform.localPosition = _positionOffset;
			transform.localRotation = Quaternion.identity;
		}
		else
		{
			transform.parent = null;
		}
		Utils.SetLayerRecursively(transform.gameObject, (transform2 != null) ? transform2.gameObject.layer : 0);
		ProjectileMoveScript projectileMoveScript = transform.gameObject.AddComponent<ProjectileMoveScript>();
		projectileMoveScript.itemProjectile = forId;
		projectileMoveScript.itemValueProjectile = itemValue;
		projectileMoveScript.itemValueLauncher = null; // _actionData.invData.holdingEntity.inventory.holdingItemItemValue;
		projectileMoveScript.itemActionProjectile = (ItemActionProjectile)((forId.Actions[0] is ItemActionProjectile) ? forId.Actions[0] : forId.Actions[1]);
		projectileMoveScript.ProjectileOwnerID = null; //entityId;
		projectileMoveScript.actionData = itemActionDataLauncher;
		transform.gameObject.SetActive(true);
		return transform; */
	}
    public static void proj(EntityPlayer player, Emplacement place, IDictionary<string, string> attr_xml) {
        player.​SetVelocity​(new Vector3(20,0,0));        
        player.speedVertical = (float) 10.0;
        player.velocityChanged = true;
    }

}


// voler:placer des blocks collidant invisible au bon rythme + tryin to unstick player ?
// 


// ? 3e arg de Buffs.AddBuff ?
// this.targets[j].Buffs.AddBuff(this.buffNames[i], _params.Self.entityId, !_params.Self.isEntityRemote);

/*
Dans un requirement
_params.Self.MinEventContext.Biome == null

Faction myFaction = FactionManager.Instance.GetFaction(_params.Self.factionId);


Dans un : MinEventActionBuffModifierBase
Debug.Log(" Self: " + _params.Self.EntityName + " Faction: " + _params.Self.factionId);
                        if (this.targets[j].factionId == _params.Self.factionId)
                            this.targets[j].Buffs.AddBuff(this.buffNames[i], _params.Self.entityId, !_params.Self.isEntityRemote);

        if (_params.Self as EntityPlayerLocal != null && this.CreateItem != null && this.CreateItemCount > 0)
        {
            ItemStack itemStack = new ItemStack(ItemClass.GetItem(this.CreateItem, false), this.CreateItemCount);
            if (!LocalPlayerUI.GetUIForPlayer(entityPlayer).xui.PlayerInventory.AddItem(itemStack, true))
            {
                entityPlayer.world.gameManager.ItemDropServer(itemStack, entityPlayer.GetPosition(), Vector3.zero, -1, 60f, false);
            }
        }



*/