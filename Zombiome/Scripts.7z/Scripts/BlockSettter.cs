using System.Xml;
using System;
using System.Collections;
using UnityEngine;
using System.Collections.Generic;

using Harmony;


using System.Linq;
using System.Reflection.Emit;


public class BlockSetter {
    /**

    - Manage entity collision: Avoid or Push
      Must be managed, otherwise "zombie felt out of the world", or player stuck (even after "trying to unstick them")

    - Manage blocks!
        - Elastic : Push or attract, recursively
                    For y axis only (other axis possible, but less guaranteed vertical support for moved blocks)
        - Avoid
        - TODO: small decoration only, terrain only ...
        - TODO: water
        - TODO: elastic down

    **/

    
    /* FIXME: I need unicize the above blocks and entities when applying push up, just before any yield 

    Block.HasTileEntity, OnBlockRemoved(), PlaceBlock()

    chunkSync3.StopStabilityCalculation = false;

    TileEntity.public static TileEntity Instantiate(TileEntityType type, Chunk _chunk)


    if (this.isMultiBlock && _blockValue.ischild)
	{
		Vector3i parentPos = this.multiBlockPos.GetParentPos(_blockPos, _blockValue);
		BlockValue block = _world.GetBlock(parentPos);
    
    */
    public Block block;
    public int LCBradius = 20;
    public bool avoidEntity = false;
    public bool avoidBlock = false; // old erase
    public int rec = 5;

    // public bool avoidSmallDeco = false;
    // private IDictionary<Entity,Integer> entities = new Dictionary<Entity,Integer>();
    // private IDictionary<Tuple<Integer>,Integer> hauteurs = new Dictionary<Entity,Integer>(); // last non air block

    private IDictionary<Entity,int> CollideH = new Dictionary<Entity,int>();

    public int ApplyAndRec(Vector3i where, BlockValue existing) {
        IDictionary<Entity,int> collide = new Dictionary<Entity,int>();
        World world = GameManager.Instance.World;   
        GameManager.Instance.World.SetBlockRPC(0, where, GenBlockValue(block));
        int k=0;    
        for (k=0; k<rec; k++) {            
            where = where + Vectors.Up;            
            BlockValue next = world.GetBlock(where); // get before set !
            world.SetBlockRPC(0, where, existing); 
            existing = next;
            /// FIXME: not just air ? if not ground dont push ? (wht does set at surface does not go on surface ???)
            if (next.type == BlockValue.Air.type) return k;
        }
        return k;
    }

    public int ApplyDownAndRec(Vector3i where) {
        IDictionary<Entity,int> collide = new Dictionary<Entity,int>();
        World world = GameManager.Instance.World;   
        GameManager.Instance.World.SetBlockRPC(0, where, GenBlockValue(block));
        int k=0;    
        for (k=0; k<rec; k++) {            
            where = where + Vectors.Up;            
            BlockValue next = world.GetBlock(where); // get before set !
            // Debug.Log(String.Format("ApplyDownAndRec {0} {1} {2}", k, where, next));
            if (next.type == BlockValue.Air.type) return k;
            world.SetBlockRPC(0, where + Vectors.Down, next);
        }
        return k;
    }

    private static ISet<Entity> NoEntities = new HashSet<Entity>();
    public ISet<Entity> Apply(Vector3i where) {
        // entities a cheval will be pushed to the max only (same for blocks)
        World world = GameManager.Instance.World;
        BlockValue existing = world.GetBlock(where);
        
        if (this.avoidBlock && existing.type != BlockValue.Air.type) return NoEntities;
        if (this.LCBradius > 0) {
            Vector3i down = new Vector3i(where.x - LCBradius, 0, where.z - LCBradius);
            Vector3i up = new Vector3i(where.x + LCBradius, 254, where.z + LCBradius);            
            GameUtils.EPlayerHomeType hy = GameUtils.CheckForAnyPlayerHome(world, down, up);
            if (hy != GameUtils.EPlayerHomeType.None) return NoEntities;
        }
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity), GetBounds(where, block, 0), new List<Entity>());
        if (this.avoidEntity && entitiesInBounds.Count > 0) return NoEntities;
        // careful is elastic + avoidEntity, and there are entities above 
        // entities must always be managed : either avoid or push

        // int extraPush = ApplyAndRec(where, existing);
        int extraPush ;
        if (this.block.blockID == BlockValue.Air.type) { // TODO or water, fake air ... plus general ? || 
            extraPush = ApplyDownAndRec(where);
            // I should return and not push ? but if I want the set, i should continue and not push
        }
        extraPush = ApplyAndRec(where, existing);
        if (extraPush > 0) entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity), GetBounds(where, block, extraPush), new List<Entity>()); // Update
        
        ISet<Entity> uniques = new HashSet<Entity>(entitiesInBounds);
        foreach (Entity entity in uniques) {
            int previous_h;
            if (this.CollideH.TryGetValue(entity, out previous_h)) {
                this.CollideH[entity] = Math.Max(previous_h, where.y + extraPush + 1);                
            } else {
                this.CollideH[entity] = where.y + extraPush + 1;
            }
            Debug.Log(String.Format(" BLockSetter.CollideH {0} {1} <= {2}", entity, this.CollideH[entity], previous_h));
        }
        return uniques;
    }

    public void Push() {
        foreach(KeyValuePair<Entity,int> item in CollideH) {
            Vector3 dest = item.Key.GetPosition();
            dest = new Vector3(dest.x, dest.y, dest.z);
            dest.y = Math.Max(dest.y, 1f* item.Value + 0.05f);
            EffectsEntity.Teleport(item.Key, dest, false);
        }
        CollideH.Clear();
    }

    public static BlockValue GenBlockValue(Block block) {
        /// Return a new BlockValue, or the "singleton" Air instance.
        if (block == null) return BlockValue.Air;
        return new BlockValue((uint) block.blockID);
    }
    public static int SetBlockAt_v0(Vector3i where, Block block, IDictionary<string, string> attr_xml) {        
        bool do_it = true;
        bool ProtectLCB = true;
        World world = GameManager.Instance.World;
        BlockValue existing = world.GetBlock(where);
        if (attr_xml["erase"] == "") {            
            do_it = (existing.type == BlockValue.Air.type);  
        }
        if (ProtectLCB) {
            int radius = 20;
            Vector3i dx = new Vector3i(radius, radius, radius);
            GameUtils.EPlayerHomeType hy = GameUtils.CheckForAnyPlayerHome(world, where -dx, where + dx); // TODO: unbound y
            if (hy != GameUtils.EPlayerHomeType.None) do_it = false;
        }
        if (do_it) {
            bool air_only = (attr_xml["air_only"] != "");
            /// FIXME si le block laissé n'est vertical stable, je pourrai pas empiler dessus (eg deco)
            /// FIXME: 
            if (air_only) {
                if (! IntersectsEntities(where, block) && ! IntersectTiles(where)) { // todo: and not intesrect block !!
                    // Debug.Log(String.Format(" air only go {0}{1}{2}", where, block, block.blockID));
                    // ne surtout pas pusher, je veux contourner ...
                    GameManager.Instance.World.SetBlockRPC(0, where, GenBlockValue(block));

                }
            } else {
                // Debug.Log(String.Format(" go {0}{1}{2}", where, block, block.blockID));
                if (block.blockID != 0) { // assume blockID 0 is Air
                    PushUpTiles(where); /// before to check 
                    GameManager.Instance.World.SetBlockRPC(0, where, GenBlockValue(block)); // "existoing" must be gotten before. TODO: returned value?
                    if (existing.type != BlockValue.Air.type) {
                        // PushUpBlock(where, existing);
                        PushUpBlockRec(where, existing);
                    } 
                    
                    PushUpEntities(where, block); 
                }
            }
        }
        return 18;
    }

    public static Bounds GetBounds(Vector3i where, Block block, int extray = 0, float enlarge=0.05f) {   
        /// enlarge > 1 maybe prevents the falling mode to work
        Vector3 delta;     
        if (block.isMultiBlock) {
            // BoundsUtils.BoundsForMinMax(float mnx, float mny, float mnz, float mxx, float mxy, float mxz)
            delta = new Vector3(block.multiBlockPos.dim.x + enlarge, block.multiBlockPos.dim.y + enlarge + extray, block.multiBlockPos.dim.z + enlarge);
        } else {
            delta = new Vector3(1f + enlarge, 1f + enlarge + extray, 1f + enlarge);
            // Bounds bounds =  new Bounds(Vectors..ToFloat(where) + new Vector3(0f,1f,0f), Vector3.one * 2f);
        }
        Bounds bounds = new Bounds();
        bounds.SetMinMax(Vectors.ToFloat(where) - new Vector3(enlarge, enlarge, enlarge), Vectors.ToFloat(where) + delta);       
        return bounds;
    }


    public static bool IntersectsEntities(Vector3i where, Block block) {
        // FIXME: faster to loop and exit on first found !
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
            GetBounds(where, block, 0),
            new List<Entity>());
        if (entitiesInBounds.Count > 0) Debug.Log(String.Format("IntersectsEntities: {0} {1}", entitiesInBounds.Count, entitiesInBounds));
        return entitiesInBounds.Count > 0;
    }
    public static bool IntersectTiles(Vector3i where) {
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        return (te != null);
    }

    public static void PushUpEntities(Vector3i where, Block block) {
        // FIXME: collision with multiple blocks (adjacent) will trigger multiple push up ...
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(typeof(Entity),
            GetBounds(where, block, 0),
            new List<Entity>());
        Debug.Log(String.Format("PushUpEntitiess: {0} {1}", entitiesInBounds.Count, string.Join(",", entitiesInBounds)));
        foreach(Entity entity in entitiesInBounds) {
            //Vector3 pos = entity.GetPosition();
            //pos.y = where.y + 1.0f;
            //entity.SetPosition(pos , false); // try _bUpdatePhysics=true
            EffectsEntity.Teleport(entity, Vectors.Float.UnitY, true);
        }        
    }
    public static void PushUpBlock(Vector3i where, BlockValue existing) {
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        if (te != null) Debug.Log(String.Format("PushUpBlock: {0} {1}", te, te.entityId));
        /// essayer aussi recursivement ..
        /// TODO: if there is place above ! + unicize
        Debug.Log(String.Format("PushUpBlock :{0} {1}", where, existing));
        GameManager.Instance.World.SetBlockRPC(0, where + Vectors.Up, existing);        
    }

    public static void PushUpBlockRec(Vector3i where, BlockValue existing) {
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        if (te != null) Debug.Log(String.Format("PushUpBlockRec: {0} {1}", te, te.entityId));
        World world = GameManager.Instance.World;          
        // while(true) {
        for (int k=0; k<10; k++) {            
            where = where + Vectors.Up;            
            BlockValue next = world.GetBlock(where);
            world.SetBlockRPC(0, where, existing); 
            existing = next;
            /// FIXME: not just air ? if not ground dont push ? (wht does set at surface does not go on surface ???)
            if (next.type == BlockValue.Air.type) return;
        }
    }

    public static void PushUpTiles(Vector3i where) {
        ///        
        TileEntity te = BlockSpawnUtils.GetTileEntity(where);
        if (te != null) {
            Debug.Log(String.Format("PushUpTiles: {0} {1}", te, te.entityId));
            te.localChunkPos = te.localChunkPos + Vectors.Up; // not where+, this is relative to chunk !
            /// TODO: Trying no re-add see if lose state
            BlockSpawnUtils.ReAddTileEntity(te, where  + Vectors.Up);
            ///==> mais le trigger doit venir du OnBlockAdd de PushUpBlock.SetBlockRPC !!!
            // ==> Block.OnBlockAdded Vs. OnBlockAddedRaw, + autres choses (eg multiblock)
            // FIXME: manage chunk change
            // FIXME na pas l'air de marcher ...
        }
    }

    public static void AddBuffToRadius(String strBuff, Vector3 position, int Radius)
    {
        // If there's no radius, pick 30 blocks.
        if(Radius <= 0  )
            Radius = 30;

        World world = GameManager.Instance.World;
        List<Entity> entitiesInBounds = GameManager.Instance.World.GetEntitiesInBounds(null, new Bounds(position, Vector3.one * Radius));
        if(entitiesInBounds.Count > 0)
        {
            for(int i = 0; i < entitiesInBounds.Count; i++)
            {
                EntityAlive entity = entitiesInBounds[i] as EntityAlive;
                if(entity != null)
                {
                    if(!entity.Buffs.HasBuff(strBuff))
                        entity.Buffs.AddBuff(strBuff);
                }
            }
        }

    }

}