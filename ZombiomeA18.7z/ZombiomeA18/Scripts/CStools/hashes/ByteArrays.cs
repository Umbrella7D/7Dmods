using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSutils {

public class ByteArrays {

    public static void _Main(string[] args) {
        // string x = "p_onfire";
        // byte[] bytes = Encoding.ASCII.GetBytes(x);
        // int nb = bytes.Length;
        // List<bytes>
        // // 1 single is four byte ?


        // float[] floatArray2 = new float[byteArray.Length / 4];
        // Buffer.BlockCopy(byteArray, 0, floatArray2, 0, byteArray.Length);

        // string xx = Encoding.ASCII.GetString(bytes);
    }

}

} // END namespace